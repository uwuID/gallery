#!/usr/bin/env bash
# One-shot: create a GitHub repo, push this project, wait for the build, download the APK.
set -e
REPO="${1:-lumina-photo-editor}"
command -v git >/dev/null || { echo "Please install git first."; exit 1; }

git init -q -b main 2>/dev/null || git init -q
git add -A
git -c user.name="${GIT_AUTHOR_NAME:-Lumina}" -c user.email="${GIT_AUTHOR_EMAIL:-lumina@users.noreply.github.com}" commit -q -m "Lumina photo editor" || true

if command -v gh >/dev/null; then
  gh auth status >/dev/null 2>&1 || gh auth login
  gh repo create "$REPO" --private --source=. --remote=origin --push
  echo "Waiting for GitHub Actions to start..."
  RUN_ID=""
  for i in $(seq 1 20); do
    RUN_ID=$(gh run list --limit 1 --json databaseId -q '.[0].databaseId' 2>/dev/null || true)
    [ -n "$RUN_ID" ] && break
    sleep 3
  done
  gh run watch "$RUN_ID" --exit-status
  gh run download "$RUN_ID" -n Lumina-APK -D ./apk
  echo "Done. APK is in ./apk"
else
  echo "GitHub CLI (gh) not found."
  echo "Manual: create an empty repo on github.com, then run:"
  echo "  git remote add origin https://github.com/<you>/$REPO.git && git push -u origin main"
  echo "Then open the Actions tab -> Build APK -> download the 'Lumina-APK' artifact."
fi
