# Lumina needs no special rules.
-dontwarn **
