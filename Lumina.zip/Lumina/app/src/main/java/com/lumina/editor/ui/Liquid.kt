package com.lumina.editor.ui

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawOutline
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// ------------------------------------------------------------------ backdrop
// Glass needs something to refract. The host renders ONE backdrop bitmap behind the whole UI
// and every glass element samples that same bitmap with a refraction shader.

class Backdrop(val bitmap: Bitmap, val width: Float, val height: Float) {
    val pixels: IntArray by lazy {
        val a = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(a, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        a
    }
}

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

@Composable
fun BackdropHost(photo: Bitmap?, content: @Composable () -> Unit) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    val backdrop = remember(size, photo) {
        if (size.width > 0 && size.height > 0)
            Backdrop(makeBackdrop(size.width, size.height, photo), size.width.toFloat(), size.height.toFloat())
        else null
    }
    Box(Modifier.fillMaxSize().background(Ink).onSizeChanged { size = it }) {
        if (backdrop != null) {
            val img = remember(backdrop) { backdrop.bitmap.asImageBitmap() }
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Medium)
            CompositionLocalProvider(LocalBackdrop provides backdrop) { content() }
        }
    }
}

@Composable
fun NoBackdrop(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalBackdrop provides null, content = content)
}

private fun makeBackdrop(w: Int, h: Int, photo: Bitmap?): Bitmap {
    val s = 0.25f
    val bw = max(1, (w * s).toInt())
    val bh = max(1, (h * s).toInt())
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(bmp)
    c.drawColor(0xFF08080B.toInt())
    if (photo != null) {
        val sc = max(bw / photo.width.toFloat(), bh / photo.height.toFloat())
        val dw = photo.width * sc
        val dh = photo.height * sc
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(photo, null, RectF((bw - dw) / 2f, (bh - dh) / 2f, (bw + dw) / 2f, (bh + dh) / 2f), p)
        c.drawColor(0x9908080B.toInt())
    } else {
    }
    return bmp
}

// ------------------------------------------------------------------ refraction shader
// Port of the approach described by kube.io ("Liquid Glass in the Browser"):
// convex squircle bezel, Snell's law (n = 1.5) for the displacement, chromatic fringing,
// and a rim light with a fixed light direction. Needs Android 13+ (AGSL); older versions use the fallback.

private const val GLASS_AGSL = """
uniform shader image;
uniform float2 size;
uniform float2 origin;
uniform float radius;
uniform float bezel;
uniform float thick;
uniform float scale;

float sdRound(float2 p, float2 hs, float r) {
    float2 q = abs(p) - (hs - float2(r, r));
    return length(max(q, float2(0.0, 0.0))) + min(max(q.x, q.y), 0.0) - r;
}

float surf(float t) {
    float u = 1.0 - t;
    float u2 = u * u;
    return pow(max(1.0 - u2 * u2, 0.0), 0.25);
}

half4 main(float2 fc) {
    float2 hs = size * 0.5;
    float2 p = fc - hs;
    float r = min(radius, min(hs.x, hs.y));
    float d = -sdRound(p, hs, r);
    float gx = sdRound(p + float2(1.0, 0.0), hs, r) - sdRound(p - float2(1.0, 0.0), hs, r);
    float gy = sdRound(p + float2(0.0, 1.0), hs, r) - sdRound(p - float2(0.0, 1.0), hs, r);
    float2 outward = float2(gx, gy) / max(length(float2(gx, gy)), 0.0001);
    float t = clamp(d / max(bezel, 1.0), 0.0, 1.0);
    float2 disp = float2(0.0, 0.0);
    if (d > 0.0 && d < bezel) {
        float dt = 0.02;
        float h0 = surf(clamp(t - dt, 0.0, 1.0));
        float h1 = surf(clamp(t + dt, 0.0, 1.0));
        float s = (h1 - h0) / (2.0 * dt) * thick / max(bezel, 1.0);
        float th1 = atan(s);
        float th2 = asin(clamp(sin(th1) / 1.5, -1.0, 1.0));
        float mag = thick * surf(t) * tan(th1 - th2);
        disp = -outward * mag;
    }
    float4 c0 = image.eval(origin + (fc + disp) * scale);
    float4 cr = image.eval(origin + (fc + disp * 1.07) * scale);
    float4 cb = image.eval(origin + (fc + disp * 0.93) * scale);
    float3 col = float3(cr.r, c0.g, cb.b);
    col = mix(col, float3(1.0, 1.0, 1.0), 0.08);
    float edge = 1.0 - t;
    float ring = edge * edge * edge * edge * edge;
    float2 L = float2(0.5, -0.866);
    float lit = max(dot(outward, L), 0.0) + 0.35 * max(dot(outward, -L), 0.0);
    col += float3(ring * lit * 0.85);
    return half4(half3(clamp(col, 0.0, 1.0)), 1.0);
}
"""

@RequiresApi(33)
class GlassShader(private val backdrop: Backdrop) {
    private val shader = RuntimeShader(GLASS_AGSL)
    val brush = ShaderBrush(shader)
    var ok = true

    init {
        shader.setInputShader("image", BitmapShader(backdrop.bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP))
    }

    fun update(w: Float, h: Float, pos: Offset, radius: Float, bezel: Float, thick: Float) {
        try {
            val sc = backdrop.bitmap.width / backdrop.width
            shader.setFloatUniform("size", w, h)
            shader.setFloatUniform("origin", pos.x * sc, pos.y * sc)
            shader.setFloatUniform("radius", radius)
            shader.setFloatUniform("bezel", bezel)
            shader.setFloatUniform("thick", thick)
            shader.setFloatUniform("scale", sc)
        } catch (t: Throwable) {
            ok = false
        }
    }
}

// ------------------------------------------------------------------ liquid glass surface

fun Modifier.glass(shape: Shape = RoundedCornerShape(26.dp), strength: Float = 1f): Modifier = composed {
    val backdrop = LocalBackdrop.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    val gs = remember(backdrop) {
        if (backdrop != null && Build.VERSION.SDK_INT >= 33) runCatching { GlassShader(backdrop) }.getOrNull() else null
    }
    val s = strength
    val cpu = remember(backdrop) { CpuCache() }
    this
        .onGloballyPositioned { pos = it.positionInWindow() }
        .clip(shape)
        .drawWithCache {
            val outline = shape.createOutline(size, layoutDirection, this)
            val radius = (outline as? Outline.Rounded)?.roundRect?.topLeftCornerRadius?.x ?: 0f
            val bezel = min(min(size.width, size.height) / 2f, 16.dp.toPx())
            val thick = bezel * 1.4f
            val rim = Color.White.copy(0.30f)
            val fill = Color.White.copy(0.10f)
            onDrawWithContent {
                if (gs != null && gs.ok) {
                    gs.update(size.width, size.height, pos, radius, bezel, thick)
                    drawRect(gs.brush)
                    drawRect(Color.Black.copy(alpha = (0.10f * s).coerceAtMost(0.6f)))
                } else if (backdrop != null) {
                    // Android 12 / 12L: same refraction, computed on the CPU at low resolution.
                    val sc = backdrop.bitmap.width / backdrop.width
                    val qx = (pos.x * sc).roundToInt()
                    val qy = (pos.y * sc).roundToInt()
                    val w = size.width.roundToInt()
                    val h = size.height.roundToInt()
                    val key = ((qx.toLong() and 0xFFFF) shl 40) or ((qy.toLong() and 0xFFFF) shl 24) or
                        ((w.toLong() and 0xFFF) shl 12) or (h.toLong() and 0xFFF)
                    if (cpu.img == null || cpu.key != key) {
                        cpu.img = GlassCpu.render(backdrop, qx / sc, qy / sc, w, h, radius, bezel, thick).asImageBitmap()
                        cpu.key = key
                    }
                    drawImage(cpu.img!!, dstSize = IntSize(w, h), filterQuality = FilterQuality.Medium)
                    drawRect(Color.Black.copy(alpha = (0.10f * s).coerceAtMost(0.6f)))
                } else {
                    drawRect(Color(0xFF0B0F1A).copy(alpha = (0.30f * s).coerceAtMost(0.9f)))
                    drawRect(fill.copy(alpha = (0.10f * s).coerceAtMost(0.5f)))
                }
                drawContent()
                drawOutline(outline, rim, style = Stroke(1.dp.toPx()))
            }
        }
}

// ------------------------------------------------------------------ dark cards

private val CardBase = Color(0xFF0E0E11)

fun Modifier.card(shape: Shape = RoundedCornerShape(28.dp), alpha: Float = 1f): Modifier =
    this.clip(shape)
        .background(Color(0xFF121216).copy(alpha = alpha))
        .border(1.dp, Color.White.copy(0.10f), shape)

/** Flat coloured card (no gradients). */
fun Modifier.flatCard(color: Color, shape: Shape = RoundedCornerShape(28.dp)): Modifier =
    this.clip(shape).background(color).border(1.dp, Color.White.copy(0.08f), shape)

// ------------------------------------------------------------------ dot-matrix digits

private val GLYPHS: Map<Char, List<String>> = mapOf(
    '0' to listOf(".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."),
    '1' to listOf("..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."),
    '2' to listOf(".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"),
    '3' to listOf(".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###."),
    '4' to listOf("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."),
    '5' to listOf("#####", "#....", "####.", "....#", "....#", "#...#", ".###."),
    '6' to listOf("..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."),
    '7' to listOf("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."),
    '8' to listOf(".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."),
    '9' to listOf(".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."),
    '.' to listOf(".", ".", ".", ".", ".", ".", "#"),
)

@Composable
fun DotNumber(
    text: String,
    modifier: Modifier = Modifier,
    cell: Dp = 11.dp,
    on: Color = Color.White,
    off: Color = Color.White.copy(0.09f),
) {
    var cols = 0
    for (ch in text) cols += (GLYPHS[ch]?.get(0)?.length ?: 0) + 1
    cols = max(cols - 1, 1)
    Canvas(modifier.size(cell * cols, cell * 7)) {
        val c = cell.toPx()
        var x = 0
        for (ch in text) {
            val g = GLYPHS[ch] ?: continue
            for (r in 0 until 7) {
                for (k in g[r].indices) {
                    val center = Offset((x + k) * c + c / 2f, r * c + c / 2f)
                    drawCircle(if (g[r][k] == '#') on else off, c * 0.32f, center)
                }
            }
            x += g[0].length + 1
        }
    }
}

// ------------------------------------------------------------------ CPU refraction (Android 12 / 12L)

class CpuCache {
    var key: Long = Long.MIN_VALUE
    var img: ImageBitmap? = null
}

object GlassCpu {
    private fun sdRound(px: Float, py: Float, hx: Float, hy: Float, r: Float): Float {
        val qx = abs(px) - (hx - r)
        val qy = abs(py) - (hy - r)
        val ax = max(qx, 0f)
        val ay = max(qy, 0f)
        return sqrt(ax * ax + ay * ay) + min(max(qx, qy), 0f) - r
    }

    private fun surf(t: Float): Float {
        val u = 1f - t
        val u2 = u * u
        return max(1f - u2 * u2, 0f).pow(0.25f)
    }

    private fun chan(px: IntArray, bw: Int, bh: Int, sx: Float, sy: Float, shift: Int): Float {
        val x = (sx - 0.5f).coerceIn(0f, bw - 1f)
        val y = (sy - 0.5f).coerceIn(0f, bh - 1f)
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = min(x0 + 1, bw - 1)
        val y1 = min(y0 + 1, bh - 1)
        val fx = x - x0
        val fy = y - y0
        val a = ((px[y0 * bw + x0] shr shift) and 255).toFloat()
        val b = ((px[y0 * bw + x1] shr shift) and 255).toFloat()
        val c = ((px[y1 * bw + x0] shr shift) and 255).toFloat()
        val d = ((px[y1 * bw + x1] shr shift) and 255).toFloat()
        return ((a * (1f - fx) + b * fx) * (1f - fy) + (c * (1f - fx) + d * fx) * fy) / 255f
    }

    fun render(b: Backdrop, posX: Float, posY: Float, w: Int, h: Int, radius: Float, bezel: Float, thick: Float): Bitmap {
        val sc = b.bitmap.width / b.width
        val bw = b.bitmap.width
        val bh = b.bitmap.height
        val px = b.pixels
        val ow = max(1, (w * sc).roundToInt())
        val oh = max(1, (h * sc).roundToInt())
        val out = IntArray(ow * oh)
        val hx = w / 2f
        val hy = h / 2f
        val r = min(radius, min(hx, hy))
        val ox = posX * sc
        val oy = posY * sc
        val bz = max(bezel, 1f)
        for (j in 0 until oh) {
            for (i in 0 until ow) {
                val fx = (i + 0.5f) / ow * w
                val fy = (j + 0.5f) / oh * h
                val p0x = fx - hx
                val p0y = fy - hy
                val d = -sdRound(p0x, p0y, hx, hy, r)
                val gx = sdRound(p0x + 1f, p0y, hx, hy, r) - sdRound(p0x - 1f, p0y, hx, hy, r)
                val gy = sdRound(p0x, p0y + 1f, hx, hy, r) - sdRound(p0x, p0y - 1f, hx, hy, r)
                val gl = max(sqrt(gx * gx + gy * gy), 0.0001f)
                val nx = gx / gl
                val ny = gy / gl
                val t = (d / bz).coerceIn(0f, 1f)
                var dx = 0f
                var dy = 0f
                if (d > 0f && d < bezel) {
                    val dt = 0.02f
                    val h0 = surf((t - dt).coerceIn(0f, 1f))
                    val h1 = surf((t + dt).coerceIn(0f, 1f))
                    val s = (h1 - h0) / (2f * dt) * thick / bz
                    val th1 = atan(s)
                    val th2 = asin((sin(th1) / 1.5f).coerceIn(-1f, 1f))
                    val mag = thick * surf(t) * tan(th1 - th2)
                    dx = -nx * mag
                    dy = -ny * mag
                }
                var rr = chan(px, bw, bh, ox + (fx + dx * 1.07f) * sc, oy + (fy + dy * 1.07f) * sc, 16)
                var gg = chan(px, bw, bh, ox + (fx + dx) * sc, oy + (fy + dy) * sc, 8)
                var bb = chan(px, bw, bh, ox + (fx + dx * 0.93f) * sc, oy + (fy + dy * 0.93f) * sc, 0)
                rr += (1f - rr) * 0.08f
                gg += (1f - gg) * 0.08f
                bb += (1f - bb) * 0.08f
                val edge = 1f - t
                val e2 = edge * edge
                val ring = e2 * e2 * edge
                val lit = max(nx * 0.5f + ny * -0.866f, 0f) + 0.35f * max(-(nx * 0.5f + ny * -0.866f), 0f)
                val add = ring * lit * 0.85f
                val r8 = ((rr + add).coerceIn(0f, 1f) * 255f).toInt()
                val g8 = ((gg + add).coerceIn(0f, 1f) * 255f).toInt()
                val b8 = ((bb + add).coerceIn(0f, 1f) * 255f).toInt()
                out[j * ow + i] = (0xFF shl 24) or (r8 shl 16) or (g8 shl 8) or b8
            }
        }
        return Bitmap.createBitmap(out, ow, oh, Bitmap.Config.ARGB_8888)
    }
}
