package com.lumina.editor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.dp
import com.lumina.editor.CropRect
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private enum class Grab { None, Move, TL, TR, BL, BR, L, T, R, B }

@Composable
fun CropOverlay(
    rect: CropRect,
    ratio: Float?,
    onRect: (CropRect) -> Unit,
    modifier: Modifier = Modifier,
) {
    val rectS by rememberUpdatedState(rect)
    val ratioS by rememberUpdatedState(ratio)
    val onRectS by rememberUpdatedState(onRect)

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    if (w <= 0f || h <= 0f) return@awaitEachGesture
                    val r0 = rectS
                    var l = r0.l * w
                    var t = r0.t * h
                    var r = r0.r * w
                    var b = r0.b * h
                    val touch = 42.dp.toPx()
                    val minS = min(56.dp.toPx(), min(w, h) / 2f)
                    val p = down.position
                    val rt = ratioS

                    fun near(x: Float, y: Float) = hypot(p.x - x, p.y - y) < touch
                    val grab = when {
                        near(l, t) -> Grab.TL
                        near(r, t) -> Grab.TR
                        near(l, b) -> Grab.BL
                        near(r, b) -> Grab.BR
                        rt == null && abs(p.x - l) < touch * 0.7f && p.y in t..b -> Grab.L
                        rt == null && abs(p.x - r) < touch * 0.7f && p.y in t..b -> Grab.R
                        rt == null && abs(p.y - t) < touch * 0.7f && p.x in l..r -> Grab.T
                        rt == null && abs(p.y - b) < touch * 0.7f && p.x in l..r -> Grab.B
                        p.x in l..r && p.y in t..b -> Grab.Move
                        else -> Grab.None
                    }
                    if (grab == Grab.None) return@awaitEachGesture
                    down.consume()

                    drag(down.id) { ch ->
                        val d = ch.positionChange()
                        when (grab) {
                            Grab.Move -> {
                                val nw = r - l
                                val nh = b - t
                                l = (l + d.x).coerceIn(0f, w - nw)
                                t = (t + d.y).coerceIn(0f, h - nh)
                                r = l + nw
                                b = t + nh
                            }
                            Grab.L -> l = (l + d.x).coerceIn(0f, r - minS)
                            Grab.R -> r = (r + d.x).coerceIn(l + minS, w)
                            Grab.T -> t = (t + d.y).coerceIn(0f, b - minS)
                            Grab.B -> b = (b + d.y).coerceIn(t + minS, h)
                            Grab.TL, Grab.TR, Grab.BL, Grab.BR -> {
                                val left = grab == Grab.TL || grab == Grab.BL
                                val top = grab == Grab.TL || grab == Grab.TR
                                val px = ch.position.x.coerceIn(0f, w)
                                val py = ch.position.y.coerceIn(0f, h)
                                if (rt == null) {
                                    if (left) l = px.coerceAtMost(r - minS) else r = px.coerceAtLeast(l + minS)
                                    if (top) t = py.coerceAtMost(b - minS) else b = py.coerceAtLeast(t + minS)
                                } else {
                                    val ax = if (left) r else l
                                    val ay = if (top) b else t
                                    val sx = if (left) -1f else 1f
                                    val sy = if (top) -1f else 1f
                                    val dx = max((px - ax) * sx, minS)
                                    val dy = max((py - ay) * sy, minS)
                                    var cw = max(dx, dy * rt)
                                    var chh = cw / rt
                                    val maxW = if (sx > 0) w - ax else ax
                                    val maxH = if (sy > 0) h - ay else ay
                                    if (cw > maxW) {
                                        cw = maxW
                                        chh = cw / rt
                                    }
                                    if (chh > maxH) {
                                        chh = maxH
                                        cw = chh * rt
                                    }
                                    if (left) {
                                        r = ax
                                        l = ax - cw
                                    } else {
                                        l = ax
                                        r = ax + cw
                                    }
                                    if (top) {
                                        b = ay
                                        t = ay - chh
                                    } else {
                                        t = ay
                                        b = ay + chh
                                    }
                                }
                            }
                            Grab.None -> {}
                        }
                        onRectS(CropRect(l / w, t / h, r / w, b / h))
                        ch.consume()
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val l = rect.l * w
            val t = rect.t * h
            val r = rect.r * w
            val b = rect.b * h
            val dim = Color.Black.copy(alpha = 0.55f)
            drawRect(dim, Offset.Zero, Size(w, t))
            drawRect(dim, Offset(0f, b), Size(w, h - b))
            drawRect(dim, Offset(0f, t), Size(l, b - t))
            drawRect(dim, Offset(r, t), Size(w - r, b - t))
            drawRect(Color.White.copy(0.85f), Offset(l, t), Size(r - l, b - t), style = Stroke(1.2.dp.toPx()))
            val grid = Color.White.copy(0.30f)
            for (i in 1..2) {
                val gx = l + (r - l) * i / 3f
                val gy = t + (b - t) * i / 3f
                drawLine(grid, Offset(gx, t), Offset(gx, b), 1.dp.toPx())
                drawLine(grid, Offset(l, gy), Offset(r, gy), 1.dp.toPx())
            }
            val len = 22.dp.toPx()
            val sw = 4.dp.toPx()
            val c = Color.White
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(c, Offset(x, y), Offset(x + dx * len, y), sw, StrokeCap.Round)
                drawLine(c, Offset(x, y), Offset(x, y + dy * len), sw, StrokeCap.Round)
            }
            corner(l, t, 1f, 1f)
            corner(r, t, -1f, 1f)
            corner(l, b, 1f, -1f)
            corner(r, b, -1f, -1f)
        }
    }
}
