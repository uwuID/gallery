package com.lumina.editor

import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private data class RenderRequest(val src: Bitmap?, val base: BaseState, val forCrop: Boolean)

private class Prepared(val source: Bitmap, val preview: Bitmap, val thumb: Bitmap, val bg: Bitmap)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    companion object {
        private const val MAX_SOURCE = 3600
        private const val MAX_PREVIEW = 1280
    }

    // ---- image + render state
    var hasImage by mutableStateOf(false)
    var source: Bitmap? = null
    var previewSrc by mutableStateOf<Bitmap?>(null)
    var thumb by mutableStateOf<Bitmap?>(null)
    var bgThumb by mutableStateOf<Bitmap?>(null)
    var preview by mutableStateOf<Bitmap?>(null)
    var histogram by mutableStateOf<IntArray?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    // ---- edit state
    var state by mutableStateOf(EditState())
    var tool by mutableStateOf<Tool?>(null)
    var cropDraft by mutableStateOf<CropDraft?>(null)
    var liveStroke by mutableStateOf<StrokeItem?>(null)
    var selectedId by mutableStateOf<Long?>(null)
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    // ---- draw settings
    var brushColor by mutableIntStateOf(-1)
    var brushSize by mutableFloatStateOf(0.012f)
    var marker by mutableStateOf(false)

    private val undoStack = ArrayDeque<EditState>()
    private val redoStack = ArrayDeque<EditState>()
    private var gestureStart: EditState? = null
    private var nextId = 1L

    val selectedText: TextItem? get() = state.texts.firstOrNull { it.id == selectedId }
    val selectedSticker: StickerItem? get() = state.stickers.firstOrNull { it.id == selectedId }

    init {
        viewModelScope.launch {
            snapshotFlow { RenderRequest(previewSrc, effectiveBase(), cropDraft != null) }
                .distinctUntilChanged()
                .collectLatest { req ->
                    val src = req.src
                    if (src == null) {
                        preview = null
                        histogram = null
                        return@collectLatest
                    }
                    val job = currentCoroutineContext()[Job]
                    val out = withContext(Dispatchers.Default) {
                        ImageProcessor.renderBase(src, req.base, req.forCrop) { job?.ensureActive() }
                    }
                    preview = out
                    histogram = withContext(Dispatchers.Default) { ImageProcessor.histogram(out) }
                }
        }
    }

    private fun effectiveBase(): BaseState {
        val b = state.base()
        val d = cropDraft ?: return b
        return b.copy(rotation = d.rotation, flipH = d.flipH, flipV = d.flipV, straighten = d.straighten, crop = null)
    }

    // ------------------------------------------------------------------ loading

    fun load(uri: Uri) {
        viewModelScope.launch {
            busy = true
            val res = withContext(Dispatchers.IO) { runCatching { prepare(decode(uri)) } }
            val p = res.getOrNull()
            if (p == null) {
                message = "Couldn't open that image"
            } else {
                source = p.source
                thumb = p.thumb
                bgThumb = p.bg
                state = EditState()
                undoStack.clear()
                redoStack.clear()
                canUndo = false
                canRedo = false
                tool = null
                cropDraft = null
                selectedId = null
                liveStroke = null
                previewSrc = p.preview
                hasImage = true
            }
            busy = false
        }
    }

    fun close() {
        hasImage = false
        source = null
        previewSrc = null
        preview = null
        thumb = null
        bgThumb = null
        tool = null
        cropDraft = null
        selectedId = null
    }

    private fun decode(uri: Uri): Bitmap {
        val src = ImageDecoder.createSource(getApplication<Application>().contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longest = max(info.size.width, info.size.height)
            if (longest > MAX_SOURCE) {
                val s = MAX_SOURCE.toFloat() / longest
                decoder.setTargetSize(
                    (info.size.width * s).roundToInt().coerceAtLeast(1),
                    (info.size.height * s).roundToInt().coerceAtLeast(1)
                )
            }
        }
    }

    private fun scaleToMax(b: Bitmap, limit: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= limit) return b
        val s = limit.toFloat() / m
        return Bitmap.createScaledBitmap(
            b,
            (b.width * s).roundToInt().coerceAtLeast(1),
            (b.height * s).roundToInt().coerceAtLeast(1),
            true
        )
    }

    private fun prepare(full: Bitmap): Prepared {
        val prev = scaleToMax(full, MAX_PREVIEW)
        val side = min(prev.width, prev.height)
        val sq = Bitmap.createBitmap(prev, (prev.width - side) / 2, (prev.height - side) / 2, side, side)
        val th = Bitmap.createScaledBitmap(sq, 160, 160, true)
        val bg = scaleToMax(prev, 48)
        return Prepared(full, prev, th, bg)
    }

    // ------------------------------------------------------------------ undo / redo

    private fun pushUndo(old: EditState) {
        undoStack.addLast(old)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
        canUndo = true
        canRedo = false
    }

    fun startGesture() {
        if (gestureStart == null) gestureStart = state
    }

    fun endGesture() {
        val g = gestureStart
        gestureStart = null
        if (g != null && g != state) pushUndo(g)
    }

    fun tap(f: () -> Unit) {
        startGesture()
        f()
        endGesture()
    }

    fun commit(f: (EditState) -> EditState) {
        val old = state
        val n = f(old)
        if (n != old) {
            pushUndo(old)
            state = n
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(state)
        state = undoStack.removeLast()
        selectedId = null
        canUndo = undoStack.isNotEmpty()
        canRedo = true
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(state)
        state = redoStack.removeLast()
        selectedId = null
        canUndo = true
        canRedo = redoStack.isNotEmpty()
    }

    fun resetAll() {
        commit { EditState() }
        selectedId = null
    }

    // ------------------------------------------------------------------ tools

    fun selectTool(t: Tool?) {
        val old = tool
        if (old == Tool.Crop) cropDraft = null
        tool = if (old == t) null else t
        selectedId = null
        if (tool == Tool.Crop) {
            val s = state
            cropDraft = CropDraft(s.rotation, s.flipH, s.flipV, s.straighten, s.crop)
        }
    }

    // ---- adjust / filter / frame

    fun setAdjust(key: AdjustKey, v: Float) {
        state = state.copy(adj = key.set(state.adj, v))
    }

    fun resetAdjust(key: AdjustKey) {
        commit { it.copy(adj = key.set(it.adj, 0f)) }
    }

    fun setFilter(p: FilterPreset) {
        commit { it.copy(filter = p, filterStrength = 1f) }
    }

    fun setFilterStrength(v: Float) {
        state = state.copy(filterStrength = v)
    }

    fun setFrame(v: Float) {
        state = state.copy(frame = v)
    }

    fun setFrameColor(c: Int) {
        commit { it.copy(frameColor = c) }
    }

    fun autoEnhance() {
        val src = previewSrc ?: return
        viewModelScope.launch {
            val a = withContext(Dispatchers.Default) { ImageProcessor.autoAdjust(src) }
            commit { it.copy(adj = it.adj.copy(brightness = a.brightness, contrast = a.contrast, saturation = a.saturation)) }
            message = "Auto enhanced"
        }
    }

    // ---- crop

    fun cropRatio(): Float? {
        val d = cropDraft ?: return null
        return when (d.aspect) {
            Aspect.Free -> null
            Aspect.Original -> preview?.let { it.width.toFloat() / it.height }
            else -> d.aspect.ratio
        }
    }

    fun setAspect(a: Aspect) {
        val d = cropDraft ?: return
        cropDraft = d.copy(aspect = a)
        val ratio = cropRatio() ?: return
        val pw = preview?.width?.toFloat() ?: return
        val ph = preview?.height?.toFloat() ?: return
        var w = pw
        var h = w / ratio
        if (h > ph) {
            h = ph
            w = h * ratio
        }
        val nw = w / pw
        val nh = h / ph
        cropDraft = cropDraft?.copy(rect = CropRect((1 - nw) / 2f, (1 - nh) / 2f, (1 + nw) / 2f, (1 + nh) / 2f))
    }

    fun setCropRect(r: CropRect) {
        cropDraft = cropDraft?.copy(rect = r)
    }

    fun setStraighten(v: Float) {
        cropDraft = cropDraft?.copy(straighten = v)
    }

    fun rotateDraft() {
        cropDraft = cropDraft?.let { it.copy(rotation = (it.rotation + 90) % 360, rect = null, aspect = Aspect.Free) }
    }

    fun flipDraft(horizontal: Boolean) {
        val d = cropDraft ?: return
        val swapped = d.rotation % 180 != 0
        cropDraft = if (horizontal != swapped) d.copy(flipH = !d.flipH, rect = null, aspect = Aspect.Free)
        else d.copy(flipV = !d.flipV, rect = null, aspect = Aspect.Free)
    }

    fun resetDraft() {
        cropDraft = CropDraft(0, false, false, 0f, null)
    }

    fun applyCrop() {
        val d = cropDraft ?: return
        val old = state
        var n = old.copy(
            rotation = d.rotation, flipH = d.flipH, flipV = d.flipV,
            straighten = d.straighten, crop = d.rect?.takeIf { !it.isFull() }
        )
        if (n != old) {
            if (old.hasOverlays()) {
                n = n.copy(strokes = emptyList(), texts = emptyList(), stickers = emptyList())
                message = "Overlays were cleared to match the new framing (undo brings them back)"
            }
            pushUndo(old)
            state = n
        }
        cropDraft = null
        tool = null
    }

    fun cancelCrop() {
        cropDraft = null
        tool = null
    }

    // ---- draw

    fun startStroke(p: Offset) {
        liveStroke = StrokeItem(listOf(p), brushColor, brushSize, marker)
    }

    fun extendStroke(p: Offset) {
        val s = liveStroke ?: return
        val last = s.points.last()
        if (abs(last.x - p.x) + abs(last.y - p.y) < 0.002f) return
        liveStroke = s.copy(points = s.points + p)
    }

    fun endStroke() {
        val s = liveStroke ?: return
        liveStroke = null
        commit { it.copy(strokes = it.strokes + s) }
    }

    // ---- text & stickers

    fun selectItem(id: Long?) {
        selectedId = id
    }

    fun addText(text: String) {
        val id = nextId++
        val item = TextItem(id, text, -1, 0.5f, 0.5f, 0.09f, 0f, true, 1)
        commit { it.copy(texts = it.texts + item) }
        selectedId = id
    }

    fun addSticker(emoji: String) {
        val id = nextId++
        val item = StickerItem(id, emoji, 0.5f, 0.5f, 0.2f, 0f)
        commit { it.copy(stickers = it.stickers + item) }
        selectedId = id
    }

    fun updateText(id: Long, f: (TextItem) -> TextItem) {
        state = state.copy(texts = state.texts.map { if (it.id == id) f(it) else it })
    }

    fun updateSticker(id: Long, f: (StickerItem) -> StickerItem) {
        state = state.copy(stickers = state.stickers.map { if (it.id == id) f(it) else it })
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        commit { s -> s.copy(texts = s.texts.filter { it.id != id }, stickers = s.stickers.filter { it.id != id }) }
        selectedId = null
    }

    fun duplicateSelected() {
        val t = selectedText
        val st = selectedSticker
        val id = nextId++
        if (t != null) {
            commit { it.copy(texts = it.texts + t.copy(id = id, x = (t.x + 0.05f).coerceAtMost(0.95f), y = (t.y + 0.05f).coerceAtMost(0.95f))) }
            selectedId = id
        } else if (st != null) {
            commit { it.copy(stickers = it.stickers + st.copy(id = id, x = (st.x + 0.05f).coerceAtMost(0.95f), y = (st.y + 0.05f).coerceAtMost(0.95f))) }
            selectedId = id
        }
    }

    fun transformSelected(pan: Offset, zoom: Float, rotDeg: Float, w: Float, h: Float) {
        val id = selectedId ?: return
        val s = state
        val ti = s.texts.indexOfFirst { it.id == id }
        if (ti >= 0) {
            val t = s.texts[ti]
            val list = s.texts.toMutableList()
            list[ti] = t.copy(
                x = t.x + pan.x / w, y = t.y + pan.y / h,
                size = (t.size * zoom).coerceIn(0.02f, 0.6f), rotation = t.rotation + rotDeg
            )
            state = s.copy(texts = list)
            return
        }
        val si = s.stickers.indexOfFirst { it.id == id }
        if (si >= 0) {
            val t = s.stickers[si]
            val list = s.stickers.toMutableList()
            list[si] = t.copy(
                x = t.x + pan.x / w, y = t.y + pan.y / h,
                size = (t.size * zoom).coerceIn(0.04f, 1.2f), rotation = t.rotation + rotDeg
            )
            state = s.copy(stickers = list)
        }
    }

    fun pickItem(p: Offset, w: Float, h: Float, pad: Float, texts: Boolean, stickers: Boolean): Long? {
        val s = state
        fun hit(cx: Float, cy: Float, rot: Float, hw: Float, hh: Float): Boolean {
            val dx = p.x - cx
            val dy = p.y - cy
            val a = Math.toRadians(-rot.toDouble())
            val rx = (dx * cos(a) - dy * sin(a)).toFloat()
            val ry = (dx * sin(a) + dy * cos(a)).toFloat()
            return abs(rx) <= hw + pad && abs(ry) <= hh + pad
        }
        if (texts) {
            for (t in s.texts.asReversed()) {
                val (hw, hh) = OverlayRenderer.textHalfExtents(t, w)
                if (hit(t.x * w, t.y * h, t.rotation, hw, hh)) return t.id
            }
        }
        if (stickers) {
            for (st in s.stickers.asReversed()) {
                val half = st.size * w * 0.62f
                if (hit(st.x * w, st.y * h, st.rotation, half, half)) return st.id
            }
        }
        return null
    }

    // ------------------------------------------------------------------ export

    fun export(format: ExportFormat, quality: Int, onSaved: (Uri) -> Unit, share: Boolean) {
        val src = source ?: return
        val st = state
        viewModelScope.launch {
            busy = true
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val base = ImageProcessor.renderBase(src, st.base())
                    val out = if (base.isMutable) base else base.copy(Bitmap.Config.ARGB_8888, true)
                    OverlayRenderer.draw(Canvas(out), out.width.toFloat(), out.height.toFloat(), st.strokes, st.stickers, st.texts, null)
                    saveToGallery(out, format, quality)
                }
            }
            busy = false
            val uri = res.getOrNull()
            if (uri == null) {
                message = "Couldn't save the image"
            } else {
                if (share) onSaved(uri) else message = "Saved to Pictures/Lumina"
            }
        }
    }

    private fun saveToGallery(bmp: Bitmap, fmt: ExportFormat, quality: Int): Uri {
        val resolver = getApplication<Application>().contentResolver
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Lumina_$stamp.${fmt.ext}")
            put(MediaStore.Images.Media.MIME_TYPE, fmt.mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Lumina")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("insert failed")
        try {
            resolver.openOutputStream(uri)!!.use { bmp.compress(fmt.compressFormat(), quality, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
