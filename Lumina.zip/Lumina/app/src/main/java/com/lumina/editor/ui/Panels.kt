package com.lumina.editor.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumina.editor.AdjustKey
import com.lumina.editor.Aspect
import com.lumina.editor.EditorViewModel
import com.lumina.editor.FilterPreset
import com.lumina.editor.ImageProcessor
import com.lumina.editor.Tool
import kotlin.math.roundToInt

// ------------------------------------------------------------------ host

@Composable
fun ToolPanelHost(vm: EditorViewModel) {
    AnimatedContent(
        targetState = vm.tool,
        transitionSpec = { fadeIn(androidx.compose.animation.core.tween(220, delayMillis = 60)) togetherWith fadeOut(androidx.compose.animation.core.tween(120)) },
        label = "panel"
    ) { t ->
        if (t == null) {
            Spacer(Modifier.height(0.dp))
        } else {
            Box(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .fillMaxWidth()
                    .card(RoundedCornerShape(28.dp), 0.88f)
                    .padding(14.dp)
            ) {
                when (t) {
                    Tool.Crop -> CropPanel(vm)
                    Tool.Adjust -> AdjustPanel(vm)
                    Tool.Filters -> FiltersPanel(vm)
                    Tool.Draw -> DrawPanel(vm)
                    Tool.Text -> TextPanel(vm)
                    Tool.Stickers -> StickerPanel(vm)
                    Tool.Frame -> FramePanel(vm)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ crop

@Composable
private fun CropPanel(vm: EditorViewModel) {
    val d = vm.cropDraft ?: return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Aspect.entries.forEach { a -> GlassChip(a.label, d.aspect == a) { vm.setAspect(a) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassIconButton(Icons.Rounded.RotateRight, "Rotate", { vm.rotateDraft() }, size = 42.dp)
            GlassIconButton(Icons.Rounded.Flip, "Flip horizontally", { vm.flipDraft(true) }, size = 42.dp)
            GlassIconButton(Icons.Rounded.Flip, "Flip vertically", { vm.flipDraft(false) }, size = 42.dp, iconRotation = 90f)
            Column(Modifier.weight(1f)) {
                Row {
                    GText("Straighten", size = 12.sp, color = Color.White.copy(0.7f))
                    Spacer(Modifier.weight(1f))
                    GText("${(d.straighten * 10f).roundToInt() / 10f}°", size = 12.sp, color = Color.White.copy(0.7f))
                }
                GlassSlider(d.straighten, { vm.setStraighten(it) }, range = -30f..30f)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton("Reset", { vm.resetDraft() }, Modifier.weight(1f), primary = false, compact = true)
            GlassButton("Cancel", { vm.cancelCrop() }, Modifier.weight(1f), icon = Icons.Rounded.Close, primary = false, compact = true)
            GlassButton("Apply", { vm.applyCrop() }, Modifier.weight(1f), icon = Icons.Rounded.Check, compact = true)
        }
    }
}

// ------------------------------------------------------------------ adjust

@Composable
private fun AdjustPanel(vm: EditorViewModel) {
    var group by remember { mutableIntStateOf(0) }
    val groups = listOf(
        "Light" to listOf(AdjustKey.Exposure, AdjustKey.Brightness, AdjustKey.Contrast, AdjustKey.Fade),
        "Color" to listOf(AdjustKey.Saturation, AdjustKey.Warmth, AdjustKey.Tint, AdjustKey.Hue),
        "Detail" to listOf(AdjustKey.Sharpen, AdjustKey.Blur, AdjustKey.Vignette, AdjustKey.Grain),
    )
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                groups.forEachIndexed { i, g -> GlassChip(g.first, i == group) { group = i } }
                GlassChip("Auto", false, Icons.Rounded.AutoFixHigh) { vm.autoEnhance() }
                GlassChip("Reset", false) { vm.resetAll() }
            }
            Spacer(Modifier.width(8.dp))
            Histogram(vm.histogram, Modifier.width(64.dp).height(30.dp))
        }
        Spacer(Modifier.height(4.dp))
        AnimatedContent(
            targetState = group,
            transitionSpec = { fadeIn(androidx.compose.animation.core.tween(180)) togetherWith fadeOut(androidx.compose.animation.core.tween(100)) },
            label = "adjgroup"
        ) { gi ->
            Column {
                groups[gi].second.forEach { key -> AdjustRow(vm, key) }
            }
        }
    }
}

@Composable
private fun AdjustRow(vm: EditorViewModel, key: AdjustKey) {
    val v = key.get(vm.state.adj)
    val shown = if (key == AdjustKey.Hue) (v * 180f).roundToInt() else (v * 100f).roundToInt()
    Row(verticalAlignment = Alignment.CenterVertically) {
        GText(
            key.label,
            Modifier.width(84.dp).bounceClick(true) { vm.resetAdjust(key) },
            size = 13.sp,
            color = Color.White.copy(0.85f)
        )
        GlassSlider(
            v, { vm.setAdjust(key, it) }, Modifier.weight(1f),
            range = key.min..key.max, onStart = { vm.startGesture() }, onEnd = { vm.endGesture() }
        )
        GText("$shown", Modifier.width(38.dp), size = 12.sp, color = Color.White.copy(0.65f))
    }
}

@Composable
fun Histogram(data: IntArray?, modifier: Modifier = Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(8.dp)).background(Color.White.copy(0.06f))) {
        val d = data ?: return@Canvas
        var mx = 1
        for (i in 0 until 768) if (d[i] > mx) mx = d[i]
        val cols = listOf(Color(0xFFFF5A5F), Color(0xFF5BE37D), Color(0xFF5B8CFF))
        for (c in 0..2) {
            val path = Path()
            path.moveTo(0f, size.height)
            for (i in 0..255) {
                val x = i / 255f * size.width
                val y = size.height - (d[c * 256 + i].toFloat() / mx).coerceAtMost(1f) * size.height * 0.95f
                path.lineTo(x, y)
            }
            path.lineTo(size.width, size.height)
            path.close()
            drawPath(path, cols[c].copy(alpha = 0.55f), blendMode = BlendMode.Plus)
        }
    }
}

// ------------------------------------------------------------------ filters

@Composable
private fun FiltersPanel(vm: EditorViewModel) {
    val thumb = vm.thumb
    val img = remember(thumb) { thumb?.asImageBitmap() }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(horizontal = 2.dp)) {
            items(FilterPreset.entries.toList()) { p ->
                val sel = vm.state.filter == p
                Column(
                    Modifier.bounceClick(true) { vm.setFilter(p) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(if (sel) 2.5.dp else 1.dp, if (sel) Accent else Color.White.copy(0.25f), RoundedCornerShape(18.dp))
                    ) {
                        if (img != null) {
                            Image(
                                img, null, Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(ColorMatrix(ImageProcessor.filterArray(p)))
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    GText(p.label, size = 11.sp, color = if (sel) Accent else Color.White.copy(0.8f))
                }
            }
        }
        if (vm.state.filter != FilterPreset.None) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GText("Strength", Modifier.width(84.dp), size = 13.sp, color = Color.White.copy(0.85f))
                GlassSlider(
                    vm.state.filterStrength, { vm.setFilterStrength(it) }, Modifier.weight(1f),
                    onStart = { vm.startGesture() }, onEnd = { vm.endGesture() }
                )
                GText("${(vm.state.filterStrength * 100).roundToInt()}", Modifier.width(38.dp), size = 12.sp, color = Color.White.copy(0.65f))
            }
        }
    }
}

// ------------------------------------------------------------------ draw

@Composable
private fun DrawPanel(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassChip("Pen", !vm.marker, Icons.Rounded.Brush) { vm.marker = false }
            GlassChip("Marker", vm.marker, Icons.Rounded.Edit) { vm.marker = true }
            Spacer(Modifier.weight(1f))
            GlassIconButton(Icons.Rounded.Undo, "Undo", { vm.undo() }, enabled = vm.canUndo, size = 38.dp)
        }
        ColorRow(vm.brushColor) { vm.brushColor = it }
        Row(verticalAlignment = Alignment.CenterVertically) {
            GText("Size", Modifier.width(56.dp), size = 13.sp, color = Color.White.copy(0.85f))
            GlassSlider(vm.brushSize, { vm.brushSize = it }, Modifier.weight(1f), range = 0.003f..0.05f)
        }
    }
}

// ------------------------------------------------------------------ text

@Composable
private fun TextPanel(vm: EditorViewModel) {
    var dialog by remember { mutableStateOf<String?>(null) } // "new" | "edit"
    val sel = vm.selectedText
    Column(
        Modifier.heightIn(max = 270.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassButton("Add text", { dialog = "new" }, icon = Icons.Rounded.Edit, compact = true)
            if (sel != null) {
                Spacer(Modifier.weight(1f))
                GlassIconButton(Icons.Rounded.Edit, "Edit", { dialog = "edit" }, size = 38.dp)
                GlassIconButton(Icons.Rounded.ContentCopy, "Duplicate", { vm.tap { vm.duplicateSelected() } }, size = 38.dp)
                GlassIconButton(Icons.Rounded.Delete, "Delete", { vm.deleteSelected() }, size = 38.dp)
            }
        }
        if (sel == null) {
            GText("Tap a text on the photo to edit it. Drag to move, pinch to scale and rotate.", size = 12.sp, color = Color.White.copy(0.6f))
        } else {
            ColorRow(sel.color) { c -> vm.tap { vm.updateText(sel.id) { it.copy(color = c) } } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("Plain", sel.style == 0) { vm.tap { vm.updateText(sel.id) { it.copy(style = 0) } } }
                GlassChip("Shadow", sel.style == 1) { vm.tap { vm.updateText(sel.id) { it.copy(style = 1) } } }
                GlassChip("Box", sel.style == 2) { vm.tap { vm.updateText(sel.id) { it.copy(style = 2) } } }
                GlassChip("Bold", sel.bold) { vm.tap { vm.updateText(sel.id) { it.copy(bold = !it.bold) } } }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                GText("Size", Modifier.width(56.dp), size = 13.sp, color = Color.White.copy(0.85f))
                GlassSlider(
                    sel.size, { v -> vm.updateText(sel.id) { it.copy(size = v) } }, Modifier.weight(1f),
                    range = 0.03f..0.3f, onStart = { vm.startGesture() }, onEnd = { vm.endGesture() }
                )
            }
        }
    }
    when (dialog) {
        "new" -> TextEditDialog("", { dialog = null }) { vm.addText(it); dialog = null }
        "edit" -> if (sel != null) {
            TextEditDialog(sel.text, { dialog = null }) { txt ->
                vm.tap { vm.updateText(sel.id) { it.copy(text = txt) } }
                dialog = null
            }
        }
    }
}

// ------------------------------------------------------------------ stickers

private val Emojis = listOf(
    "😀", "😎", "🥰", "😂", "🤩", "😍", "🥳", "😴", "🤔", "🙌",
    "🔥", "✨", "💫", "⭐", "🌈", "❤️", "💙", "💜", "🖤", "💯",
    "🎉", "🎈", "🎁", "🌸", "🌺", "🍀", "🌙", "☀️", "⚡", "❄️",
    "🐶", "🐱", "🦋", "🌴", "🍕", "🍔", "☕", "🎵", "💎", "👑",
    "🕶️", "🎀", "✅", "❌", "📍", "📸", "🏆", "🚀", "🌍", "👍"
)

@Composable
private fun StickerPanel(vm: EditorViewModel) {
    val sel = vm.selectedSticker
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (rowIdx in 0..1) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Emojis.filterIndexed { i, _ -> i % 2 == rowIdx }.forEach { e ->
                        Box(Modifier.size(48.dp).bounceClick(true) { vm.addSticker(e) }, contentAlignment = Alignment.Center) {
                            GText(e, size = 28.sp)
                        }
                    }
                }
            }
        }
        if (sel == null) {
            GText("Tap a sticker to add it. Drag to move, pinch to scale and rotate.", size = 12.sp, color = Color.White.copy(0.6f))
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GText("Size", Modifier.width(48.dp), size = 13.sp, color = Color.White.copy(0.85f))
                GlassSlider(
                    sel.size, { v -> vm.updateSticker(sel.id) { it.copy(size = v) } }, Modifier.weight(1f),
                    range = 0.05f..0.8f, onStart = { vm.startGesture() }, onEnd = { vm.endGesture() }
                )
                GlassIconButton(Icons.Rounded.ContentCopy, "Duplicate", { vm.tap { vm.duplicateSelected() } }, size = 38.dp)
                GlassIconButton(Icons.Rounded.Delete, "Delete", { vm.deleteSelected() }, size = 38.dp)
            }
        }
    }
}

// ------------------------------------------------------------------ frame

@Composable
private fun FramePanel(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GText("Thickness", Modifier.width(84.dp), size = 13.sp, color = Color.White.copy(0.85f))
            GlassSlider(
                vm.state.frame, { vm.setFrame(it) }, Modifier.weight(1f),
                range = 0f..0.12f, onStart = { vm.startGesture() }, onEnd = { vm.endGesture() }
            )
        }
        GText("Color", size = 13.sp, color = Color.White.copy(0.85f))
        ColorRow(vm.state.frameColor) { vm.setFrameColor(it) }
    }
}
