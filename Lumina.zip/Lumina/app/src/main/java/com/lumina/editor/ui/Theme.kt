package com.lumina.editor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF070912)
val Accent = Color(0xFF7CF4FF)
val Violet = Color(0xFFB69CFF)
val Pink = Color(0xFFFF8FD6)

private val Scheme = darkColorScheme(
    primary = Accent,
    secondary = Violet,
    tertiary = Pink,
    background = Ink,
    surface = Ink,
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun LuminaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}
