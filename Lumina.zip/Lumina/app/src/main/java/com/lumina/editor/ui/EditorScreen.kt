package com.lumina.editor.ui

import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BorderOuter
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compare
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumina.editor.EditorViewModel
import com.lumina.editor.OverlayRenderer
import com.lumina.editor.Tool
import kotlinx.coroutines.launch
import kotlin.math.abs

private fun Tool.icon(): ImageVector = when (this) {
    Tool.Crop -> Icons.Rounded.Crop
    Tool.Adjust -> Icons.Rounded.Tune
    Tool.Filters -> Icons.Rounded.AutoAwesome
    Tool.Draw -> Icons.Rounded.Brush
    Tool.Text -> Icons.Rounded.TextFields
    Tool.Stickers -> Icons.Rounded.EmojiEmotions
    Tool.Frame -> Icons.Rounded.BorderOuter
}

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val ctx = LocalContext.current
    var showSave by remember { mutableStateOf(false) }
    var showDiscard by remember { mutableStateOf(false) }
    var showOriginal by remember { mutableStateOf(false) }

    BackHandler {
        when {
            vm.tool != null -> vm.selectTool(null)
            vm.canUndo -> showDiscard = true
            else -> vm.close()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            TopBar(
                vm,
                onClose = { if (vm.canUndo) showDiscard = true else vm.close() },
                onHold = { showOriginal = it },
                onSave = { showSave = true }
            )
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
                CanvasArea(vm, showOriginal)
            }
            ToolPanelHost(vm)
            BottomToolbar(vm)
        }
    }

    if (showSave) {
        SaveDialog(onDismiss = { showSave = false }) { fmt, quality, share ->
            showSave = false
            vm.export(fmt, quality, onSaved = { uri ->
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = fmt.mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "Share"))
            }, share = share)
        }
    }
    if (showDiscard) {
        DiscardDialog(onDismiss = { showDiscard = false }) {
            showDiscard = false
            vm.close()
        }
    }
}

// ------------------------------------------------------------------ backdrop + bars

@Composable
private fun TopBar(vm: EditorViewModel, onClose: () -> Unit, onHold: (Boolean) -> Unit, onSave: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        GlassIconButton(Icons.Rounded.Close, "Close", onClose, size = 44.dp)
        GlassIconButton(Icons.Rounded.Undo, "Undo", { vm.undo() }, enabled = vm.canUndo, size = 44.dp)
        GlassIconButton(Icons.Rounded.Redo, "Redo", { vm.redo() }, enabled = vm.canRedo, size = 44.dp)
        Spacer(Modifier.weight(1f))
        HoldIconButton(Icons.Rounded.Compare, "Hold to compare", onHold)
        GlassButton("Save", onSave, icon = Icons.Rounded.SaveAlt, compact = true)
    }
}

@Composable
private fun BottomToolbar(vm: EditorViewModel) {
    val tools = Tool.entries
    val itemW = 62.dp
    val sel = vm.tool?.let { tools.indexOf(it) } ?: -1
    val targetX = if (sel >= 0) itemW * sel else 0.dp
    val x by animateDpAsState(targetX, spring(dampingRatio = 0.55f, stiffness = 300f), label = "pill")
    val pillAlpha by animateFloatAsState(if (sel >= 0) 1f else 0f, tween(200), label = "pillAlpha")
    val stretch = 1f + (abs(targetX.value - x.value) / itemW.value).coerceAtMost(1.5f) * 0.22f

    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .glass(RoundedCornerShape(30.dp))
                .padding(6.dp)
                .horizontalScroll(rememberScrollState())
        ) {
            Box(
                Modifier
                    .offset(x = x)
                    .size(itemW, 54.dp)
                    .graphicsLayer { scaleX = stretch; alpha = pillAlpha }
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(0.22f))
                    .border(1.dp, Color.White.copy(0.55f), RoundedCornerShape(22.dp))
            )
            Row {
                tools.forEach { t ->
                    val selected = vm.tool == t
                    Column(
                        Modifier.width(itemW).height(54.dp).bounceClick(true) { vm.selectTool(t) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(t.icon(), t.name, tint = if (selected) Color.White else Color.White.copy(0.72f), modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(3.dp))
                        GText(
                            t.name.uppercase(), size = 9.sp, mono = true,
                            weight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (selected) Color.White else Color.White.copy(0.72f)
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ canvas

@Composable
private fun CanvasArea(vm: EditorViewModel, showOriginal: Boolean) {
    val shown = if (showOriginal) vm.previewSrc else vm.preview
    val layoutBmp = vm.preview ?: vm.previewSrc
    val tool = vm.tool
    val scope = rememberCoroutineScope()
    var zoom by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var container by remember { mutableStateOf(IntSize.Zero) }
    val sizeState = remember { mutableStateOf(IntSize.Zero) }
    val zoomable = tool == null || tool == Tool.Adjust || tool == Tool.Filters || tool == Tool.Frame

    fun resetZoom() {
        val z0 = zoom
        val o0 = offset
        if (z0 == 1f && o0 == Offset.Zero) return
        scope.launch {
            animate(0f, 1f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 250f)) { f, _ ->
                zoom = z0 + (1f - z0) * f
                offset = o0 * (1f - f)
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(zoomable) { if (!zoomable) resetZoom() }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { container = it }
            .pointerInput(zoomable) {
                if (zoomable) {
                    detectTransformGestures { _, pan, z, _ ->
                        val nz = (zoom * z).coerceIn(1f, 8f)
                        val mx = (nz - 1f) * container.width / 2f
                        val my = (nz - 1f) * container.height / 2f
                        zoom = nz
                        offset = if (nz <= 1.001f) Offset.Zero
                        else Offset((offset.x + pan.x).coerceIn(-mx, mx), (offset.y + pan.y).coerceIn(-my, my))
                    }
                }
            }
            .pointerInput(zoomable) {
                if (zoomable) {
                    detectTapGestures(onDoubleTap = {
                        if (zoom > 1.05f) resetZoom()
                        else scope.launch {
                            animate(zoom, 2.4f, animationSpec = spring(dampingRatio = 0.8f, stiffness = 250f)) { v, _ -> zoom = v }
                        }
                    })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (layoutBmp != null && shown != null) {
            val ratio = layoutBmp.width.toFloat() / layoutBmp.height
            val img = remember(shown) { shown.asImageBitmap() }
            Box(
                Modifier
                    .aspectRatio(ratio)
                    .graphicsLayer {
                        scaleX = zoom
                        scaleY = zoom
                        translationX = offset.x
                        translationY = offset.y
                    }
                    .clip(RoundedCornerShape(16.dp))
                    .onSizeChanged { sizeState.value = it }
                    .then(toolGestures(vm, tool, sizeState))
            ) {
                Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, filterQuality = FilterQuality.High)
                val draft = vm.cropDraft
                if (draft != null) {
                    if (!showOriginal) {
                        CropOverlay(
                            rect = draft.rect ?: com.lumina.editor.CropRect(0f, 0f, 1f, 1f),
                            ratio = vm.cropRatio(),
                            onRect = { vm.setCropRect(it) }
                        )
                    }
                } else if (!showOriginal) {
                    OverlayLayer(vm)
                }
            }
        }
    }
}

@Composable
private fun toolGestures(vm: EditorViewModel, tool: Tool?, sizeState: androidx.compose.runtime.MutableState<IntSize>): Modifier = when (tool) {
    Tool.Draw -> Modifier.pointerInput("draw") {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val sz = sizeState.value
            if (sz.width == 0 || sz.height == 0) return@awaitEachGesture
            fun norm(o: Offset) = Offset((o.x / sz.width).coerceIn(0f, 1f), (o.y / sz.height).coerceIn(0f, 1f))
            vm.startStroke(norm(down.position))
            down.consume()
            do {
                val event = awaitPointerEvent()
                val ch = event.changes.firstOrNull { it.id == down.id }
                if (ch != null && ch.positionChanged()) {
                    vm.extendStroke(norm(ch.position))
                    ch.consume()
                }
            } while (event.changes.any { it.pressed })
            vm.endStroke()
        }
    }
    Tool.Text, Tool.Stickers -> Modifier.pointerInput("items-$tool") {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val sz = sizeState.value
            if (sz.width == 0 || sz.height == 0) return@awaitEachGesture
            val w = sz.width.toFloat()
            val h = sz.height.toFloat()
            val hit = vm.pickItem(down.position, w, h, 18.dp.toPx(), tool == Tool.Text, tool == Tool.Stickers)
            if (hit != null) vm.selectItem(hit)
            vm.startGesture()
            var moved = false
            var total = Offset.Zero
            val slop = viewConfiguration.touchSlop
            do {
                val event = awaitPointerEvent()
                val zoomChange = event.calculateZoom()
                val pan = event.calculatePan()
                val rot = event.calculateRotation()
                total += pan
                if (!moved && (total.getDistance() > slop || event.changes.size > 1)) moved = true
                if (moved && (zoomChange != 1f || pan != Offset.Zero || rot != 0f)) {
                    vm.transformSelected(pan, zoomChange, rot, w, h)
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            } while (event.changes.any { it.pressed })
            vm.endGesture()
            if (!moved && hit == null) vm.selectItem(null)
        }
    }
    else -> Modifier
}

@Composable
private fun OverlayLayer(vm: EditorViewModel) {
    Canvas(Modifier.fillMaxSize()) {
        val s = vm.state
        drawIntoCanvas { c ->
            OverlayRenderer.draw(c.nativeCanvas, size.width, size.height, s.strokes, s.stickers, s.texts, vm.liveStroke)
        }
        val id = vm.selectedId
        if (id != null && (vm.tool == Tool.Text || vm.tool == Tool.Stickers)) {
            var cx = 0f
            var cy = 0f
            var hw = 0f
            var hh = 0f
            var rot = 0f
            var found = false
            val t = s.texts.firstOrNull { it.id == id }
            val st = s.stickers.firstOrNull { it.id == id }
            if (t != null) {
                val (a, b) = OverlayRenderer.textHalfExtents(t, size.width)
                cx = t.x * size.width; cy = t.y * size.height; hw = a; hh = b; rot = t.rotation; found = true
            } else if (st != null) {
                val half = st.size * size.width * 0.62f
                cx = st.x * size.width; cy = st.y * size.height; hw = half; hh = half; rot = st.rotation; found = true
            }
            if (found) {
                rotate(rot, Offset(cx, cy)) {
                    drawRoundRect(
                        Accent, Offset(cx - hw, cy - hh), Size(hw * 2f, hh * 2f), CornerRadius(12.dp.toPx()),
                        style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f)))
                    )
                }
            }
        }
    }
}
