package com.lumina.editor.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumina.editor.ExportFormat
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun TextEditDialog(initial: String, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val fr = remember { FocusRequester() }
    GlassDialog(onDismiss) {
        GText("Text", size = 20.sp, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.8f).padding(16.dp)) {
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
                cursorBrush = SolidColor(Accent),
                modifier = Modifier.fillMaxWidth().focusRequester(fr)
            )
            if (text.isEmpty()) GText("Type something", size = 20.sp, color = Color.White.copy(0.4f))
        }
        LaunchedEffect(Unit) {
            delay(150)
            runCatching { fr.requestFocus() }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton("Cancel", onDismiss, Modifier.weight(1f), icon = Icons.Rounded.Close, primary = false, compact = true)
            GlassButton("Done", { onDone(text.trim()) }, Modifier.weight(1f), icon = Icons.Rounded.Check, enabled = text.isNotBlank(), compact = true)
        }
    }
}

@Composable
fun SaveDialog(onDismiss: () -> Unit, onSave: (ExportFormat, Int, Boolean) -> Unit) {
    var fmt by remember { mutableStateOf(ExportFormat.Jpeg) }
    var q by remember { mutableFloatStateOf(0.92f) }
    GlassDialog(onDismiss) {
        GText("Export", size = 20.sp, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ExportFormat.entries.forEach { f -> GlassChip(f.label, fmt == f) { fmt = f } }
        }
        AnimatedVisibility(visible = fmt != ExportFormat.Png) {
            androidx.compose.foundation.layout.Column {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth()) {
                    GText("Quality", size = 13.sp, color = Color.White.copy(0.8f))
                    Spacer(Modifier.weight(1f))
                    GText("${(q * 100).roundToInt()}%", size = 13.sp, color = Color.White.copy(0.8f))
                }
                GlassSlider(q, { q = it }, range = 0.5f..1f)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton("Share", { onSave(fmt, (q * 100).roundToInt(), true) }, Modifier.weight(1f), icon = Icons.Rounded.Share, primary = false, compact = true)
            GlassButton("Save", { onSave(fmt, (q * 100).roundToInt(), false) }, Modifier.weight(1f), icon = Icons.Rounded.SaveAlt, compact = true)
        }
    }
}

@Composable
fun DiscardDialog(onDismiss: () -> Unit, onDiscard: () -> Unit) {
    GlassDialog(onDismiss) {
        GText("Discard edits?", size = 20.sp, weight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        GText("Your changes to this photo will be lost.", size = 14.sp, color = Color.White.copy(0.7f))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton("Keep editing", onDismiss, Modifier.weight(1f), primary = false, compact = true)
            GlassButton("Discard", onDiscard, Modifier.weight(1f), compact = true)
        }
    }
}
