package com.lumina.editor

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max

/** Draws strokes, stickers and text with plain android.graphics so preview and export are identical. */
object OverlayRenderer {

    fun draw(
        c: Canvas,
        w: Float,
        h: Float,
        strokes: List<StrokeItem>,
        stickers: List<StickerItem>,
        texts: List<TextItem>,
        live: StrokeItem?,
    ) {
        val p = Paint()
        for (s in strokes) drawStroke(c, s, w, h, p)
        if (live != null) drawStroke(c, live, w, h, p)
        for (s in stickers) drawSticker(c, s, w, h, p)
        for (t in texts) drawText(c, t, w, h, p)
    }

    private fun drawStroke(c: Canvas, s: StrokeItem, w: Float, h: Float, p: Paint) {
        if (s.points.isEmpty()) return
        p.reset()
        p.isAntiAlias = true
        p.color = s.color
        val sw = s.size * w * (if (s.marker) 2.2f else 1f)
        if (s.marker) p.alpha = 110
        if (s.points.size == 1) {
            p.style = Paint.Style.FILL
            c.drawCircle(s.points[0].x * w, s.points[0].y * h, sw / 2f, p)
            return
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = sw
        val path = Path()
        var prev = s.points[0]
        path.moveTo(prev.x * w, prev.y * h)
        for (i in 1 until s.points.size) {
            val cur = s.points[i]
            val mx = (prev.x + cur.x) / 2f * w
            val my = (prev.y + cur.y) / 2f * h
            path.quadTo(prev.x * w, prev.y * h, mx, my)
            prev = cur
        }
        path.lineTo(prev.x * w, prev.y * h)
        c.drawPath(path, p)
    }

    private fun drawSticker(c: Canvas, s: StickerItem, w: Float, h: Float, p: Paint) {
        p.reset()
        p.isAntiAlias = true
        p.textSize = s.size * w
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.save()
        c.translate(s.x * w, s.y * h)
        c.rotate(s.rotation)
        c.drawText(s.emoji, 0f, -(fm.ascent + fm.descent) / 2f, p)
        c.restore()
    }

    private fun typeface(bold: Boolean): Typeface =
        if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT

    private fun drawText(c: Canvas, t: TextItem, w: Float, h: Float, p: Paint) {
        val size = t.size * w
        p.reset()
        p.isAntiAlias = true
        p.textSize = size
        p.textAlign = Paint.Align.CENTER
        p.typeface = typeface(t.bold)
        val lines = t.text.split("\n")
        val lh = size * 1.18f
        val total = lh * lines.size
        val fm = p.fontMetrics
        val off = -(fm.ascent + fm.descent) / 2f
        c.save()
        c.translate(t.x * w, t.y * h)
        c.rotate(t.rotation)
        if (t.style == 2) {
            var mw = 0f
            for (l in lines) mw = max(mw, p.measureText(l))
            val pad = size * 0.35f
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            val lum = (android.graphics.Color.red(t.color) * 0.299f + android.graphics.Color.green(t.color) * 0.587f + android.graphics.Color.blue(t.color) * 0.114f)
            bg.color = if (lum > 150f) 0xB3000000.toInt() else 0xE6FFFFFF.toInt()
            c.drawRoundRect(RectF(-mw / 2f - pad, -total / 2f - pad * 0.5f, mw / 2f + pad, total / 2f + pad * 0.5f), pad, pad, bg)
        }
        p.color = t.color
        if (t.style == 1) p.setShadowLayer(size * 0.08f, 0f, size * 0.04f, 0xAA000000.toInt())
        for (i in lines.indices) {
            c.drawText(lines[i], 0f, -total / 2f + lh * i + lh / 2f + off, p)
        }
        c.restore()
    }

    /** Half width / half height of a text item in pixels (unrotated). */
    fun textHalfExtents(t: TextItem, w: Float): Pair<Float, Float> {
        val size = t.size * w
        val p = Paint()
        p.textSize = size
        p.typeface = typeface(t.bold)
        val lines = t.text.split("\n")
        var mw = 0f
        for (l in lines) mw = max(mw, p.measureText(l))
        val lh = size * 1.18f
        return Pair(mw / 2f + size * 0.3f, lh * lines.size / 2f + size * 0.2f)
    }
}
