package com.lumina.editor

import android.graphics.Bitmap
import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset

@Immutable
data class Adjustments(
    val exposure: Float = 0f,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val fade: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
    val tint: Float = 0f,
    val hue: Float = 0f,
    val sharpen: Float = 0f,
    val blur: Float = 0f,
    val vignette: Float = 0f,
    val grain: Float = 0f,
)

enum class AdjustKey(val label: String, val min: Float, val max: Float) {
    Exposure("Exposure", -1f, 1f),
    Brightness("Brightness", -1f, 1f),
    Contrast("Contrast", -1f, 1f),
    Fade("Fade", 0f, 1f),
    Saturation("Saturation", -1f, 1f),
    Warmth("Warmth", -1f, 1f),
    Tint("Tint", -1f, 1f),
    Hue("Hue", -1f, 1f),
    Sharpen("Sharpen", 0f, 1f),
    Blur("Blur", 0f, 1f),
    Vignette("Vignette", 0f, 1f),
    Grain("Grain", 0f, 1f);

    fun get(a: Adjustments): Float = when (this) {
        Exposure -> a.exposure
        Brightness -> a.brightness
        Contrast -> a.contrast
        Fade -> a.fade
        Saturation -> a.saturation
        Warmth -> a.warmth
        Tint -> a.tint
        Hue -> a.hue
        Sharpen -> a.sharpen
        Blur -> a.blur
        Vignette -> a.vignette
        Grain -> a.grain
    }

    fun set(a: Adjustments, v: Float): Adjustments = when (this) {
        Exposure -> a.copy(exposure = v)
        Brightness -> a.copy(brightness = v)
        Contrast -> a.copy(contrast = v)
        Fade -> a.copy(fade = v)
        Saturation -> a.copy(saturation = v)
        Warmth -> a.copy(warmth = v)
        Tint -> a.copy(tint = v)
        Hue -> a.copy(hue = v)
        Sharpen -> a.copy(sharpen = v)
        Blur -> a.copy(blur = v)
        Vignette -> a.copy(vignette = v)
        Grain -> a.copy(grain = v)
    }
}

enum class FilterPreset(val label: String) {
    None("Original"), Vivid("Vivid"), Drama("Drama"), Noir("Noir"), Mono("Mono"),
    Sepia("Sepia"), Fade("Fade"), Cool("Cool"), Warm("Warm"), Vintage("Vintage"),
    Chrome("Chrome"), Matte("Matte"), Sunset("Sunset"), Teal("Teal"), Dream("Dream")
}

@Immutable
data class CropRect(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w: Float get() = r - l
    val h: Float get() = b - t
    fun isFull(): Boolean = w > 0.999f && h > 0.999f
}

@Immutable
data class StrokeItem(
    val points: List<Offset>,
    val color: Int,
    val size: Float,        // fraction of image width
    val marker: Boolean,
)

@Immutable
data class TextItem(
    val id: Long,
    val text: String,
    val color: Int,
    val x: Float,           // centre, 0..1 of width
    val y: Float,           // centre, 0..1 of height
    val size: Float,        // fraction of image width
    val rotation: Float,
    val bold: Boolean,
    val style: Int,         // 0 plain, 1 shadow, 2 box
)

@Immutable
data class StickerItem(
    val id: Long,
    val emoji: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val rotation: Float,
)

/** Everything that changes the pixels of the base image (not overlays). */
@Immutable
data class BaseState(
    val adj: Adjustments,
    val filter: FilterPreset,
    val filterStrength: Float,
    val rotation: Int,
    val flipH: Boolean,
    val flipV: Boolean,
    val straighten: Float,
    val crop: CropRect?,
    val frame: Float,
    val frameColor: Int,
)

@Immutable
data class EditState(
    val adj: Adjustments = Adjustments(),
    val filter: FilterPreset = FilterPreset.None,
    val filterStrength: Float = 1f,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val straighten: Float = 0f,
    val crop: CropRect? = null,
    val frame: Float = 0f,
    val frameColor: Int = -1, // white
    val strokes: List<StrokeItem> = emptyList(),
    val texts: List<TextItem> = emptyList(),
    val stickers: List<StickerItem> = emptyList(),
) {
    fun base() = BaseState(adj, filter, filterStrength, rotation, flipH, flipV, straighten, crop, frame, frameColor)
    fun hasOverlays() = strokes.isNotEmpty() || texts.isNotEmpty() || stickers.isNotEmpty()
}

enum class Tool { Crop, Adjust, Filters, Draw, Text, Stickers, Frame }

enum class Aspect(val label: String, val ratio: Float) {
    Free("Free", 0f), Original("Original", -1f), Square("1:1", 1f),
    R43("4:3", 4f / 3f), R34("3:4", 3f / 4f), R169("16:9", 16f / 9f),
    R916("9:16", 9f / 16f), R32("3:2", 1.5f), R23("2:3", 2f / 3f)
}

data class CropDraft(
    val rotation: Int,
    val flipH: Boolean,
    val flipV: Boolean,
    val straighten: Float,
    val rect: CropRect?,
    val aspect: Aspect = Aspect.Free,
)

enum class ExportFormat(val label: String, val ext: String, val mime: String) {
    Jpeg("JPG", "jpg", "image/jpeg"),
    Png("PNG", "png", "image/png"),
    Webp("WEBP", "webp", "image/webp");

    @Suppress("DEPRECATION")
    fun compressFormat(): Bitmap.CompressFormat = when (this) {
        Jpeg -> Bitmap.CompressFormat.JPEG
        Png -> Bitmap.CompressFormat.PNG
        Webp -> if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
    }
}
