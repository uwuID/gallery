package com.lumina.editor.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumina.editor.EditorViewModel
import kotlinx.coroutines.delay

@Composable
fun LuminaApp(vm: EditorViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.load(uri)
    }
    val openPicker = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    BackdropHost(photo = if (vm.hasImage) vm.bgThumb else null) {
        Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = vm.hasImage,
                transitionSpec = {
                    (fadeIn(tween(420)) + scaleIn(initialScale = 0.96f, animationSpec = tween(420))) togetherWith fadeOut(tween(260))
                },
                label = "root"
            ) { has ->
                if (has) EditorScreen(vm) else HomeScreen(vm, onOpen = { openPicker() })
            }

            // toast
            val msg = vm.message
            var lastMsg by remember { mutableStateOf("") }
            LaunchedEffect(msg) {
                if (msg != null) {
                    lastMsg = msg
                    delay(2600)
                    vm.message = null
                }
            }
            AnimatedVisibility(
                visible = msg != null,
                enter = slideInVertically(spring(0.7f, 400f)) { -it } + fadeIn(),
                exit = slideOutVertically(tween(200)) { -it } + fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp, start = 24.dp, end = 24.dp)
            ) {
                Box(Modifier.glass(RoundedCornerShape(50), 1.4f).padding(horizontal = 20.dp, vertical = 12.dp)) {
                    GText(lastMsg, size = 13.sp)
                }
            }

            // busy overlay
            AnimatedVisibility(visible = vm.busy, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(0.4f))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(84.dp).glass(CircleShape, 1.3f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(34.dp))
                    }
                }
            }
        }
    }
}
