package com.lumina.editor.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(onOpen: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    val enter by animateFloatAsState(if (show) 1f else 0f, spring(0.75f, 60f), label = "enter")

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(28.dp)
                .graphicsLayer { alpha = enter; translationY = (1f - enter) * 90f },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            LensLogo(Modifier.size(170.dp))
            Spacer(Modifier.height(30.dp))
            GText("Lumina", size = 46.sp, weight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            GText(
                "Edit photos with light and glass",
                color = Color.White.copy(0.65f), size = 15.sp, align = TextAlign.Center
            )
            Spacer(Modifier.height(40.dp))
            GlassButton("Open photo", onOpen, icon = Icons.Rounded.PhotoLibrary)
            Spacer(Modifier.height(34.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Crop", "Adjust", "Filters", "Draw", "Text", "Stickers", "Frames").forEach { GlassTag(it) }
            }
        }
    }
}

@Composable
private fun LensLogo(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "logo")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "angle")
    val breathe by t.animateFloat(
        0.95f, 1.05f,
        infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    Canvas(modifier.graphicsLayer { scaleX = breathe; scaleY = breathe }) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val center = Offset(cx, cy)
        val r = size.minDimension / 2f * 0.88f
        // glass body
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(0.30f), Color.White.copy(0.05f)),
                center = Offset(cx - r * 0.3f, cy - r * 0.4f), radius = r * 1.5f
            ),
            r, center
        )
        // rotating prism ring
        rotate(angle, center) {
            drawCircle(
                Brush.sweepGradient(listOf(Accent, Violet, Pink, Accent), center = center),
                r, center, style = Stroke(5.dp.toPx())
            )
        }
        drawCircle(Color.White.copy(0.35f), r * 0.78f, center, style = Stroke(1.dp.toPx()))
        // specular highlight
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(0.55f), Color.Transparent),
                center = Offset(cx - r * 0.35f, cy - r * 0.45f), radius = r * 0.5f
            ),
            r * 0.5f, Offset(cx - r * 0.35f, cy - r * 0.45f)
        )
        // sparkle
        val s = r * 0.34f
        val star = Path()
        star.moveTo(cx, cy - s)
        star.quadraticBezierTo(cx, cy, cx + s, cy)
        star.quadraticBezierTo(cx, cy, cx, cy + s)
        star.quadraticBezierTo(cx, cy, cx - s, cy)
        star.quadraticBezierTo(cx, cy, cx, cy - s)
        star.close()
        drawPath(star, Color.White)
    }
}
