package com.lumina.editor.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumina.editor.EditorViewModel
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

@Composable
private fun Modifier.stagger(show: Boolean, index: Int): Modifier {
    val a by animateFloatAsState(
        if (show) 1f else 0f,
        tween(520, delayMillis = index * 70, easing = FastOutSlowInEasing),
        label = "stagger"
    )
    return this.graphicsLayer { alpha = a; translationY = (1f - a) * 60f }
}

@Composable
fun HomeScreen(vm: EditorViewModel, onOpen: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    val date = remember {
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEE, d MMM · H:mm", Locale.ENGLISH)).uppercase(Locale.ENGLISH)
    }
    val gray = Color.White.copy(0.55f)
    val total = vm.savedTotal
    val week = vm.weekCounts
    val weekTotal = vm.weekTotal

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // header
        Row(Modifier.fillMaxWidth().stagger(show, 0).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                GText(date, size = 11.sp, mono = true, color = gray)
                Spacer(Modifier.height(4.dp))
                GText("Lumina", size = 30.sp, weight = FontWeight.Medium)
            }
            Box(Modifier.size(44.dp).glass(CircleShape), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(22.dp)) {
                    val c = center
                    val s = size.minDimension / 2f
                    val star = Path()
                    star.moveTo(c.x, c.y - s)
                    star.quadraticBezierTo(c.x, c.y, c.x + s, c.y)
                    star.quadraticBezierTo(c.x, c.y, c.x, c.y + s)
                    star.quadraticBezierTo(c.x, c.y, c.x - s, c.y)
                    star.quadraticBezierTo(c.x, c.y, c.x, c.y - s)
                    star.close()
                    drawPath(star, Color.White)
                }
            }
        }

        // hero: photos saved
        Column(
            Modifier
                .fillMaxWidth()
                .height(272.dp)
                .stagger(show, 1)
                .flatCard(Color(0xFF3A1633))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Image, null, tint = Color.White.copy(0.8f), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                GText("Photos saved", size = 14.sp, color = Color.White.copy(0.85f))
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color.White.copy(0.10f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Info, null, tint = Color.White.copy(0.7f), modifier = Modifier.size(14.dp))
                }
            }
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                DotNumber(total.toString().padStart(3, '0'))
                Spacer(Modifier.height(10.dp))
                GText("EXPORTED · $weekTotal THIS WEEK", size = 10.sp, mono = true, color = gray)
            }
            Sparkline(week, Modifier.fillMaxWidth().height(64.dp))
        }

        // filters + adjust
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                Modifier
                    .weight(1f)
                    .height(172.dp)
                    .stagger(show, 2)
                    .bounceClick(true, onOpen)
                    .flatCard(Color(0xFF16206E))
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White.copy(0.85f), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    GText("Filters", size = 14.sp)
                }
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        GText("15", size = 36.sp, weight = FontWeight.Light)
                        Spacer(Modifier.width(4.dp))
                        GText("presets", size = 13.sp, color = gray)
                    }
                    Spacer(Modifier.height(10.dp))
                    Bars(Modifier.fillMaxWidth().height(38.dp))
                }
            }
            Column(
                Modifier
                    .weight(1f)
                    .height(172.dp)
                    .stagger(show, 3)
                    .bounceClick(true, onOpen)
                    .flatCard(Color(0xFF6B2A10))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Tune, null, tint = Color.White.copy(0.85f), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    GText("Adjust", size = 14.sp)
                }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Dial(Modifier.fillMaxSize())
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        GText("12", size = 28.sp, weight = FontWeight.Light)
                        GText("TOOLS", size = 9.sp, mono = true, color = gray)
                    }
                }
            }
        }

        // weekly goal
        Column(
            Modifier
                .fillMaxWidth()
                .stagger(show, 4)
                .card(RoundedCornerShape(26.dp))
                .padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Flag, null, tint = Color.White.copy(0.8f), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                GText("Weekly goal", size = 14.sp)
                Spacer(Modifier.weight(1f))
                GText("$weekTotal / 10", size = 12.sp, mono = true, color = Color.White.copy(0.8f))
            }
            Spacer(Modifier.height(10.dp))
            DotProgress((weekTotal / 10f).coerceIn(0f, 1f))
        }

        // open photo: liquid glass pill
        Row(
            Modifier
                .fillMaxWidth()
                .height(66.dp)
                .stagger(show, 5)
                .bounceClick(true, onOpen)
                .glass(RoundedCornerShape(50))
                .padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PhotoLibrary, null, tint = Color.Black, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            GText("Open photo", size = 16.sp, weight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF7CE38B)))
            Spacer(Modifier.width(7.dp))
            GText("READY", size = 10.sp, mono = true, color = gray)
            Spacer(Modifier.width(14.dp))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Sparkline(values: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = values.size
        if (n < 2) return@Canvas
        val mx = max(values.maxOrNull() ?: 1, 1)
        val padX = 8.dp.toPx()
        val padY = 9.dp.toPx()
        fun px(i: Int) = padX + (size.width - 2 * padX) * i / (n - 1)
        fun py(v: Int) = size.height - padY - (size.height - 2 * padY) * (0.3f + 0.7f * v / mx)
        val path = Path()
        path.moveTo(px(0), py(values[0]))
        for (i in 1 until n) {
            val mid = (px(i - 1) + px(i)) / 2f
            path.cubicTo(mid, py(values[i - 1]), mid, py(values[i]), px(i), py(values[i]))
        }
        drawPath(path, Color.White, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(Color.White, 3.dp.toPx(), Offset(px(0), py(values[0])))
        drawCircle(Color.White.copy(0.25f), 12.dp.toPx(), Offset(px(n - 1), py(values[n - 1])))
        drawCircle(Color.White, 7.dp.toPx(), Offset(px(n - 1), py(values[n - 1])))
    }
}

@Composable
private fun Bars(modifier: Modifier = Modifier) {
    val hs = listOf(0.35f, 0.5f, 0.42f, 0.6f, 0.48f, 0.7f, 0.55f, 0.66f, 1f, 0.62f, 0.5f, 0.58f, 0.44f, 0.52f)
    Canvas(modifier) {
        val n = hs.size
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val h = size.height * hs[i]
            drawRoundRect(
                if (i == 8) Color.White else Color.White.copy(0.35f),
                Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 2f)
            )
        }
    }
}

@Composable
private fun Dial(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val n = 48
        for (i in 0 until n) {
            val a = (i * 2.0 * PI / n - PI / 2.0).toFloat()
            val inner = r * 0.80f
            val outer = r * 0.96f
            drawLine(
                if (i < 36) Color.White.copy(0.92f) else Color.White.copy(0.25f),
                Offset(c.x + cos(a) * inner, c.y + sin(a) * inner),
                Offset(c.x + cos(a) * outer, c.y + sin(a) * outer),
                1.6.dp.toPx(), StrokeCap.Round
            )
        }
    }
}

@Composable
private fun DotProgress(frac: Float, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(28.dp)) {
        val pad = 12.dp.toPx()
        val cy = size.height / 2f
        val left = pad
        val right = size.width - pad
        val gap = 8.dp.toPx()
        val n = ((right - left) / gap).toInt().coerceAtLeast(1)
        val x = left + (right - left) * frac
        for (i in 0..n) {
            val dx = left + (right - left) * i / n
            drawCircle(if (dx <= x) Color.White.copy(0.95f) else Color.White.copy(0.2f), 1.6.dp.toPx(), Offset(dx, cy))
        }
        drawCircle(Color.White.copy(0.2f), 16.dp.toPx(), Offset(x, cy))
        drawCircle(Color.White, 9.dp.toPx(), Offset(x, cy))
    }
}
