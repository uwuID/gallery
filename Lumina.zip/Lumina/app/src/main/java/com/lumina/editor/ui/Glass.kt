package com.lumina.editor.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------- liquid glass surface

private val GlassBorder = Brush.linearGradient(
    listOf(Color.White.copy(0.80f), Color.White.copy(0.06f), Color.White.copy(0.34f))
)

/** Frosted, refractive-looking surface: tinted body + specular top band + gradient rim. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(26.dp), strength: Float = 1f): Modifier = this
    .clip(shape)
    .drawBehind {
        drawRect(Color(0xFF0B0F1A).copy(alpha = (0.28f * strength).coerceAtMost(0.9f)))
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy((0.22f * strength).coerceAtMost(0.9f)), Color.White.copy((0.06f * strength).coerceAtMost(0.9f)))
            )
        )
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy((0.18f * strength).coerceAtMost(0.9f)), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.45f
            )
        )
    }
    .border(1.dp, GlassBorder, shape)

/** Springy press feedback. */
fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.90f else 1f,
        spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

// ---------------------------------------------------------------- text

@Composable
fun GText(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 14.sp,
    weight: FontWeight = FontWeight.Medium,
    color: Color = Color.White,
    align: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
) {
    Text(text, modifier, color = color, fontSize = size, fontWeight = weight, textAlign = align, maxLines = maxLines)
}

// ---------------------------------------------------------------- buttons

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    size: Dp = 46.dp,
    iconRotation: Float = 0f,
    tint: Color = Color.White,
) {
    Box(
        modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.35f)
            .bounceClick(enabled, onClick)
            .glass(CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(size * 0.48f).rotate(iconRotation))
    }
}

@Composable
fun HoldIconButton(icon: ImageVector, desc: String, onHold: (Boolean) -> Unit, size: Dp = 44.dp) {
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onHold)
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, spring(0.45f, 500f), label = "hold")
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .glass(CircleShape, if (pressed) 1.8f else 1f)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    cb(true)
                    tryAwaitRelease()
                    pressed = false
                    cb(false)
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(size * 0.48f))
    }
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primary: Boolean = true,
    enabled: Boolean = true,
    compact: Boolean = false,
) {
    val shape = RoundedCornerShape(50)
    val fill: Brush = if (primary)
        Brush.horizontalGradient(listOf(Accent.copy(0.55f), Violet.copy(0.55f)))
    else SolidColor(Color.White.copy(0.10f))
    Row(
        modifier
            .alpha(if (enabled) 1f else 0.4f)
            .bounceClick(enabled, onClick)
            .clip(shape)
            .background(fill)
            .glass(shape, 0.8f)
            .padding(horizontal = if (compact) 16.dp else 26.dp, vertical = if (compact) 10.dp else 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(if (compact) 18.dp else 22.dp))
            Box(Modifier.size(8.dp))
        }
        GText(text, size = if (compact) 14.sp else 16.sp, weight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassChip(text: String, selected: Boolean, icon: ImageVector? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill: Brush = if (selected)
        Brush.horizontalGradient(listOf(Accent.copy(0.50f), Violet.copy(0.50f)))
    else SolidColor(Color.White.copy(0.10f))
    Row(
        Modifier
            .bounceClick(true, onClick)
            .clip(shape)
            .background(fill)
            .border(1.dp, if (selected) Color.White.copy(0.6f) else Color.White.copy(0.2f), shape)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
            Box(Modifier.size(6.dp))
        }
        GText(text, size = 13.sp, weight = FontWeight.Medium)
    }
}

@Composable
fun GlassTag(text: String) {
    Box(Modifier.glass(RoundedCornerShape(50), 0.7f).padding(horizontal = 14.dp, vertical = 7.dp)) {
        GText(text, size = 12.sp, color = Color.White.copy(0.85f))
    }
}

// ---------------------------------------------------------------- colour palette

val Palette = listOf(
    Color.White, Color.Black, Color(0xFFFF5A5F), Color(0xFFFFB84D), Color(0xFFFFE066),
    Color(0xFF7CE38B), Color(0xFF7CF4FF), Color(0xFF5B8CFF), Color(0xFFB69CFF), Color(0xFFFF8FD6)
)

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Palette.forEach { c ->
            val sel = c.toArgb() == selected
            val sc by animateFloatAsState(if (sel) 1.2f else 1f, spring(0.5f, 400f), label = "dot")
            Box(
                Modifier
                    .size(30.dp)
                    .graphicsLayer { scaleX = sc; scaleY = sc }
                    .clip(CircleShape)
                    .background(c)
                    .border(if (sel) 2.5.dp else 1.dp, if (sel) Accent else Color.White.copy(0.5f), CircleShape)
                    .bounceClick(true) { onPick(c.toArgb()) }
            )
        }
    }
}

// ---------------------------------------------------------------- slider

@Composable
fun GlassSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    onStart: () -> Unit = {},
    onEnd: () -> Unit = {},
) {
    val haptic = LocalHapticFeedback.current
    val onChange by rememberUpdatedState(onValueChange)
    val startCb by rememberUpdatedState(onStart)
    val endCb by rememberUpdatedState(onEnd)
    var dragging by remember { mutableStateOf(false) }
    val thumbScale by animateFloatAsState(if (dragging) 1.3f else 1f, spring(0.5f, 380f), label = "thumb")
    val glow by animateFloatAsState(if (dragging) 1f else 0f, tween(200), label = "glow")
    val span = range.endInclusive - range.start
    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
    val zeroFrac = (-range.start / span).coerceIn(0f, 1f)
    val snapZero = range.start < 0f

    Box(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .pointerInput(range) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val pad = 14.dp.toPx()
                    var snapped = false
                    fun emit(x: Float) {
                        val f = ((x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                        var v = range.start + f * span
                        if (snapZero && abs(v) < span * 0.03f) {
                            v = 0f
                            if (!snapped) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                snapped = true
                            }
                        } else {
                            snapped = false
                        }
                        onChange(v)
                    }
                    dragging = true
                    startCb()
                    emit(down.position.x)
                    down.consume()
                    drag(down.id) { ch ->
                        emit(ch.position.x)
                        ch.consume()
                    }
                    dragging = false
                    endCb()
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val pad = 14.dp.toPx()
            val trackH = 5.dp.toPx()
            val cy = size.height / 2f
            val left = pad
            val right = size.width - pad
            val x = left + (right - left) * frac
            val x0 = left + (right - left) * zeroFrac
            drawRoundRect(
                Color.White.copy(0.18f), Offset(left, cy - trackH / 2f),
                Size(right - left, trackH), CornerRadius(trackH / 2f)
            )
            val a = min(x, x0)
            val b = max(x, x0)
            if (b - a > 0.5f) {
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Accent, Violet), startX = left, endX = right),
                    Offset(a, cy - trackH / 2f), Size(b - a, trackH), CornerRadius(trackH / 2f)
                )
            }
            if (snapZero) {
                drawRoundRect(
                    Color.White.copy(0.55f), Offset(x0 - 1.dp.toPx(), cy - 8.dp.toPx()),
                    Size(2.dp.toPx(), 16.dp.toPx()), CornerRadius(1.dp.toPx())
                )
            }
            val r = 12.dp.toPx() * thumbScale
            drawCircle(Accent.copy(alpha = 0.30f * glow), r * 1.9f, Offset(x, cy))
            drawCircle(
                Brush.radialGradient(
                    listOf(Color.White, Color(0xFFD6E6FF)),
                    center = Offset(x - r * 0.3f, cy - r * 0.3f), radius = r * 1.5f
                ),
                r, Offset(x, cy)
            )
            drawCircle(Color.White.copy(0.9f), r, Offset(x, cy), style = Stroke(1.5.dp.toPx()))
        }
    }
}

// ---------------------------------------------------------------- dialog

@Composable
fun GlassDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = shown,
                enter = fadeIn(tween(160)) + scaleIn(initialScale = 0.82f, animationSpec = spring(0.55f, 380f))
            ) {
                Column(
                    Modifier
                        .padding(24.dp)
                        .widthIn(max = 380.dp)
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(30.dp), 1.15f)
                        .background(Color(0xFF10142A).copy(alpha = 0.55f))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                        .padding(22.dp),
                    content = content
                )
            }
        }
    }
}

// ---------------------------------------------------------------- animated backdrop

@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val c by t.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "c")
    Canvas(modifier.fillMaxSize().background(Ink)) {
        val w = size.width
        val h = size.height
        val r = max(w, h) * 0.75f
        blob(Violet, Offset(w * (0.10f + 0.55f * a), h * (0.10f + 0.30f * b)), r, 0.50f)
        blob(Accent, Offset(w * (0.90f - 0.55f * b), h * (0.55f + 0.30f * c)), r * 0.9f, 0.36f)
        blob(Pink, Offset(w * (0.20f + 0.50f * c), h * (0.95f - 0.35f * a)), r * 0.8f, 0.30f)
    }
}

private fun DrawScope.blob(color: Color, center: Offset, radius: Float, alpha: Float) {
    drawCircle(
        Brush.radialGradient(listOf(color.copy(alpha), Color.Transparent), center = center, radius = radius),
        radius = radius,
        center = center
    )
}
