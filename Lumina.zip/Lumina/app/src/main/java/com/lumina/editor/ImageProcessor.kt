package com.lumina.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

object ImageProcessor {

    // ------------------------------------------------------------------ pipeline

    fun renderBase(src: Bitmap, b: BaseState, forCrop: Boolean = false, check: () -> Unit = {}): Bitmap {
        var bmp = geometry(src, b.rotation, b.flipH, b.flipV, b.straighten)
        check()
        if (!forCrop) bmp = crop(bmp, b.crop)
        check()
        val m = colorMatrix(b)
        if (m != null) bmp = applyColor(bmp, m)
        check()
        if (b.adj.blur > 0.01f) bmp = blur(bmp, b.adj.blur)
        check()
        if (b.adj.sharpen > 0.01f) bmp = sharpen(bmp, b.adj.sharpen)
        check()
        if (b.adj.grain > 0.01f) bmp = grain(bmp, b.adj.grain)
        if (b.adj.vignette > 0.01f) bmp = vignette(bmp, b.adj.vignette)
        check()
        if (!forCrop && b.frame > 0.002f) bmp = frame(bmp, b)
        return bmp
    }

    // ------------------------------------------------------------------ geometry

    private fun geometry(src: Bitmap, rotation: Int, flipH: Boolean, flipV: Boolean, straighten: Float): Bitmap {
        val rot = ((rotation % 360) + 360) % 360
        if (rot == 0 && !flipH && !flipV && abs(straighten) < 0.01f) return src
        val w = src.width
        val h = src.height
        val swap = rot == 90 || rot == 270
        val outW = if (swap) h else w
        val outH = if (swap) w else h
        val m = Matrix()
        m.postTranslate(-w / 2f, -h / 2f)
        m.postScale(if (flipH) -1f else 1f, if (flipV) -1f else 1f)
        m.postRotate(rot.toFloat())
        if (abs(straighten) >= 0.01f) {
            val a = Math.toRadians(abs(straighten.toDouble()))
            val ratio = max(outW.toFloat() / outH, outH.toFloat() / outW)
            val s = (cos(a) + sin(a) * ratio).toFloat()
            m.postRotate(straighten)
            m.postScale(s, s)
        }
        m.postTranslate(outW / 2f, outH / 2f)
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        Canvas(out).drawBitmap(src, m, p)
        return out
    }

    private fun crop(src: Bitmap, c: CropRect?): Bitmap {
        if (c == null || c.isFull()) return src
        val l = (c.l * src.width).roundToInt().coerceIn(0, src.width - 1)
        val t = (c.t * src.height).roundToInt().coerceIn(0, src.height - 1)
        val r = (c.r * src.width).roundToInt().coerceIn(l + 1, src.width)
        val b = (c.b * src.height).roundToInt().coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    // ------------------------------------------------------------------ colour

    private fun cmScale(r: Float, g: Float, b: Float) = ColorMatrix(
        floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
    )

    private fun cmTranslate(r: Float, g: Float, b: Float) = ColorMatrix(
        floatArrayOf(1f, 0f, 0f, 0f, r, 0f, 1f, 0f, 0f, g, 0f, 0f, 1f, 0f, b, 0f, 0f, 0f, 1f, 0f)
    )

    private fun cmContrast(c: Float): ColorMatrix {
        val t = 128f * (1f - c)
        return ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f))
    }

    private fun cmSat(s: Float): ColorMatrix = ColorMatrix().apply { setSaturation(s) }

    private fun cmHue(deg: Float): ColorMatrix {
        val r = Math.toRadians(deg.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        val lr = 0.213f
        val lg = 0.715f
        val lb = 0.072f
        return ColorMatrix(
            floatArrayOf(
                lr + c * (1 - lr) + s * (-lr), lg + c * (-lg) + s * (-lg), lb + c * (-lb) + s * (1 - lb), 0f, 0f,
                lr + c * (-lr) + s * 0.143f, lg + c * (1 - lg) + s * 0.140f, lb + c * (-lb) + s * (-0.283f), 0f, 0f,
                lr + c * (-lr) + s * (-(1 - lr)), lg + c * (-lg) + s * lg, lb + c * (1 - lb) + s * lb, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    private fun chain(vararg m: ColorMatrix): ColorMatrix {
        val r = ColorMatrix()
        for (x in m) r.postConcat(x)
        return r
    }

    fun filterMatrix(p: FilterPreset): ColorMatrix = when (p) {
        FilterPreset.None -> ColorMatrix()
        FilterPreset.Vivid -> chain(cmSat(1.35f), cmContrast(1.1f))
        FilterPreset.Drama -> chain(cmContrast(1.35f), cmSat(0.85f), cmTranslate(-14f, -14f, -14f))
        FilterPreset.Noir -> chain(cmSat(0f), cmContrast(1.3f), cmTranslate(-6f, -6f, -6f))
        FilterPreset.Mono -> chain(cmSat(0f), cmContrast(1.05f), cmTranslate(8f, 8f, 8f))
        FilterPreset.Sepia -> ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        FilterPreset.Fade -> chain(cmSat(0.8f), cmContrast(0.85f), cmTranslate(24f, 24f, 24f))
        FilterPreset.Cool -> chain(cmScale(0.92f, 1f, 1.12f), cmSat(1.05f))
        FilterPreset.Warm -> chain(cmScale(1.12f, 1.02f, 0.86f), cmSat(1.05f))
        FilterPreset.Vintage -> chain(cmSat(0.7f), cmScale(1.1f, 1.0f, 0.8f), cmContrast(0.92f), cmTranslate(14f, 10f, 6f))
        FilterPreset.Chrome -> chain(cmContrast(1.2f), cmSat(1.2f), cmScale(0.96f, 1.03f, 1.06f))
        FilterPreset.Matte -> chain(cmContrast(0.9f), cmSat(0.9f), cmTranslate(20f, 20f, 22f))
        FilterPreset.Sunset -> chain(cmScale(1.2f, 0.96f, 0.8f), cmSat(1.2f), cmContrast(1.05f))
        FilterPreset.Teal -> chain(cmContrast(1.12f), cmScale(1.08f, 1.0f, 0.94f), cmTranslate(-6f, 4f, 10f))
        FilterPreset.Dream -> chain(cmSat(1.1f), cmContrast(0.9f), cmScale(1.05f, 1f, 1.08f), cmTranslate(12f, 8f, 14f))
    }

    fun filterArray(p: FilterPreset): FloatArray = filterMatrix(p).array

    private fun blend(arr: FloatArray, s: Float): FloatArray {
        val id = floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)
        return FloatArray(20) { id[it] * (1f - s) + arr[it] * s }
    }

    private fun colorMatrix(b: BaseState): ColorMatrix? {
        val a = b.adj
        val neutral = b.filter == FilterPreset.None && a.exposure == 0f && a.brightness == 0f &&
            a.contrast == 0f && a.fade == 0f && a.saturation == 0f && a.warmth == 0f &&
            a.tint == 0f && a.hue == 0f
        if (neutral) return null
        val list = ArrayList<ColorMatrix>()
        if (b.filter != FilterPreset.None) {
            list.add(ColorMatrix(blend(filterArray(b.filter), b.filterStrength)))
        }
        if (a.exposure != 0f) {
            val s = 2f.pow(a.exposure * 1.2f)
            list.add(cmScale(s, s, s))
        }
        if (a.brightness != 0f) {
            val t = a.brightness * 70f
            list.add(cmTranslate(t, t, t))
        }
        if (a.contrast != 0f) list.add(cmContrast(1f + a.contrast * 0.8f))
        if (a.saturation != 0f) list.add(cmSat(1f + a.saturation))
        if (a.hue != 0f) list.add(cmHue(a.hue * 180f))
        if (a.warmth != 0f) list.add(cmScale(1f + 0.2f * a.warmth, 1f + 0.02f * a.warmth, 1f - 0.2f * a.warmth))
        if (a.tint != 0f) list.add(cmScale(1f + 0.08f * a.tint, 1f - 0.18f * a.tint, 1f + 0.08f * a.tint))
        if (a.fade != 0f) {
            val s = 1f - 0.3f * a.fade
            val t = 38f * a.fade
            list.add(ColorMatrix(floatArrayOf(s, 0f, 0f, 0f, t, 0f, s, 0f, 0f, t, 0f, 0f, s, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        }
        val result = ColorMatrix()
        for (m in list) result.postConcat(m)
        return result
    }

    private fun applyColor(src: Bitmap, m: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(m)
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }

    // ------------------------------------------------------------------ pixel effects

    private fun pixels(b: Bitmap): IntArray {
        val a = IntArray(b.width * b.height)
        b.getPixels(a, 0, b.width, 0, 0, b.width, b.height)
        return a
    }

    private fun fromPixels(a: IntArray, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun mutable(b: Bitmap): Bitmap =
        if (b.isMutable && b.config == Bitmap.Config.ARGB_8888) b else b.copy(Bitmap.Config.ARGB_8888, true)

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val lineStep = if (horizontal) w else 1
        val div = 2 * r + 1
        for (line in 0 until lines) {
            val base = line * lineStep
            var rs = 0
            var gs = 0
            var bs = 0
            for (i in -r..r) {
                val p = src[base + i.coerceIn(0, len - 1) * step]
                rs += (p shr 16) and 255
                gs += (p shr 8) and 255
                bs += p and 255
            }
            for (i in 0 until len) {
                dst[base + i * step] = (0xFF shl 24) or ((rs / div) shl 16) or ((gs / div) shl 8) or (bs / div)
                val add = src[base + min(i + r + 1, len - 1) * step]
                val rem = src[base + max(i - r, 0) * step]
                rs += ((add shr 16) and 255) - ((rem shr 16) and 255)
                gs += ((add shr 8) and 255) - ((rem shr 8) and 255)
                bs += (add and 255) - (rem and 255)
            }
        }
    }

    private fun blur(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val r = (amount * 0.018f * max(w, h)).roundToInt().coerceAtLeast(1)
        val a = pixels(src)
        val t = IntArray(a.size)
        repeat(2) {
            blurPass(a, t, w, h, r, true)
            blurPass(t, a, w, h, r, false)
        }
        return fromPixels(a, w, h)
    }

    private fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val s = pixels(src)
        val d = IntArray(s.size)
        val k = amount * 1.1f
        val center = 1f + 4f * k
        for (y in 0 until h) {
            val yc = y * w
            val yu = max(y - 1, 0) * w
            val yd = min(y + 1, h - 1) * w
            for (x in 0 until w) {
                val xl = max(x - 1, 0)
                val xr = min(x + 1, w - 1)
                val c = s[yc + x]
                val l = s[yc + xl]
                val r = s[yc + xr]
                val u = s[yu + x]
                val dn = s[yd + x]
                val rr = (((c shr 16) and 255) * center - k * (((l shr 16) and 255) + ((r shr 16) and 255) + ((u shr 16) and 255) + ((dn shr 16) and 255))).toInt().coerceIn(0, 255)
                val gg = (((c shr 8) and 255) * center - k * (((l shr 8) and 255) + ((r shr 8) and 255) + ((u shr 8) and 255) + ((dn shr 8) and 255))).toInt().coerceIn(0, 255)
                val bb = ((c and 255) * center - k * ((l and 255) + (r and 255) + (u and 255) + (dn and 255))).toInt().coerceIn(0, 255)
                d[yc + x] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        return fromPixels(d, w, h)
    }

    private fun grain(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val a = pixels(src)
        var seed = 123456789
        val k = amount * 46f
        for (i in a.indices) {
            seed = seed xor (seed shl 13)
            seed = seed xor (seed ushr 17)
            seed = seed xor (seed shl 5)
            val n = ((((seed and 0xFF) - 128) / 128f) * k).toInt()
            val p = a[i]
            val r = (((p shr 16) and 255) + n).coerceIn(0, 255)
            val g = (((p shr 8) and 255) + n).coerceIn(0, 255)
            val b = ((p and 255) + n).coerceIn(0, 255)
            a[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return fromPixels(a, w, h)
    }

    private fun vignette(src: Bitmap, amount: Float): Bitmap {
        val out = mutable(src)
        val w = out.width.toFloat()
        val h = out.height.toFloat()
        val radius = hypot(w, h) / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val edge = android.graphics.Color.argb((amount * 215f).toInt().coerceIn(0, 255), 0, 0, 0)
        p.shader = RadialGradient(
            w / 2f, h / 2f, radius,
            intArrayOf(0, 0, edge),
            floatArrayOf(0f, 0.35f + (1f - amount) * 0.2f, 1f),
            Shader.TileMode.CLAMP
        )
        Canvas(out).drawRect(0f, 0f, w, h, p)
        return out
    }

    private fun frame(src: Bitmap, b: BaseState): Bitmap {
        val t = (b.frame * max(src.width, src.height)).roundToInt()
        val out = Bitmap.createBitmap(src.width + 2 * t, src.height + 2 * t, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(b.frameColor)
        c.drawBitmap(src, t.toFloat(), t.toFloat(), null)
        return out
    }

    // ------------------------------------------------------------------ analysis

    fun histogram(src: Bitmap): IntArray {
        val w = 96
        val h = (96f * src.height / src.width).roundToInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        val out = IntArray(768)
        for (p in px) {
            out[(p shr 16) and 255]++
            out[256 + ((p shr 8) and 255)]++
            out[512 + (p and 255)]++
        }
        return out
    }

    fun autoAdjust(src: Bitmap): Adjustments {
        val w = 128
        val h = (128f * src.height / src.width).roundToInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256)
        var sum = 0L
        for (p in px) {
            val l = (((p shr 16) and 255) * 54 + ((p shr 8) and 255) * 183 + (p and 255) * 19) shr 8
            hist[l]++
            sum += l
        }
        val total = px.size
        val mean = sum.toFloat() / total
        fun pct(f: Float): Int {
            var acc = 0
            val target = (total * f).toInt()
            for (i in 0..255) {
                acc += hist[i]
                if (acc >= target) return i
            }
            return 255
        }
        val lo = pct(0.01f)
        val hi = pct(0.99f)
        val scale = (255f / (hi - lo).coerceAtLeast(80)).coerceIn(1f, 1.5f)
        val contrast = ((scale - 1f) / 0.8f).coerceIn(0f, 0.6f)
        val bright = ((118f - mean) / 70f * 0.6f).coerceIn(-0.35f, 0.35f)
        return Adjustments(brightness = bright, contrast = contrast, saturation = 0.12f)
    }
}
