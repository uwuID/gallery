# Lumina

Minimal photo editor for Android with a liquid-glass interface (Kotlin + Jetpack Compose).

Tools: Crop (aspect ratios, rotate, flip, straighten), Adjust (12 sliders + auto + histogram),
15 Filters, Draw (pen/marker), Text, Stickers, Frame, undo/redo, hold-to-compare,
pinch and double-tap zoom, export JPG/PNG/WEBP, share.

## Build the APK
Push to GitHub: the workflow in `.github/workflows/build.yml` builds it.
Download the `Lumina-APK` artifact from the Actions tab.
Local build: `gradle assembleRelease` (JDK 17, Android SDK 34, Gradle 8.7).
